# Audit Comparison Bundle

Comparison of the deterministic crawler output against the agentic auditor baseline for:

- `sustainable-growth-experts.com`
- `www.assuranceskin.com`

Prepared 2026-10-29. No tool code, crawler source, or original crawl artifacts were modified.

## Read this first

- **Comparison report:** `deterministic-audit-comparison.md`
- **Agentic baseline findings and references:** Section 3 of the report
- **Detailed deterministic-only differences:** Sections 4-10
- **Prioritized developer actions:** Section 11
- **Artifact reference list:** Section 14

## Bundle layout

```text
audit-comparison-bundle/
  README.md
  SHA256SUMS
  deterministic-audit-comparison.md
  agentic/
    sustainable-growth-experts.com/
      link_graph.json
      block_decisions.json
      block_candidates.json
    www.assuranceskin.com/
      link_graph.json
      block_decisions.json
      block_candidates.json
  deterministic/
    sustainable-growth-experts.com/
      audit.json
      audit-pages.csv
      audit-links.csv
      audit-blocks.csv
    www.assuranceskin.com/
      audit.json
      audit-pages.csv
      audit-links.csv
      audit-blocks.csv
```

## Provenance

| Dataset | Source | Date |
|---|---|---|
| Agentic | Workspace crawl directories `crawls/sustainable-growth-experts-com-ce34620f6bc1/` and `crawls/www-assuranceskin-com-74743b7697f7/` | September 2026 |
| Deterministic | `misc/sample-audits.zip` | 2026-10-29 |

## What is included and what is not

Included for the agentic baseline:

- `link_graph.json` - pages, content links, orphans, PageRank, anchor data, exclusion counts
- `block_decisions.json` - the agent's content/nav/boilerplate block decisions
- `block_candidates.json` - candidate block features, anchors, snippets, and page samples

Not included:

- Agentic `crawl_raw.json` (about 62 MB for Askin). It remains in the workspace crawl directories and can be regenerated from the existing crawl artifacts if raw-link reproduction is needed.
- Agentic `html/` snapshots. They remain in the workspace crawl directories.
- Live-site HTML snapshots. Ambiguous links were checked against the live sites on 2026-10-29; the checks are listed in Section 14 of the report.

Included for the deterministic baseline:

- `audit.json`
- `audit-pages.csv`
- `audit-links.csv` (content links only; the deterministic tool does not export excluded links with reasons)
- `audit-blocks.csv`

## Important comparison caveats

- The two crawls are roughly five weeks apart. A small number of old-only links are **site drift**, not tool misses. These were verified against the live site and are called out in the report.
- URLs were normalized for scheme, `www.`, duplicate slashes, and trailing slash before comparison.
- Agentic and deterministic PageRank values are **not directly comparable** because the page/node sets and self-link/media/redirect handling differ.
- Deterministic `audit-links.csv` is content-only. Counts for nav/self/boilerplate/external/non-HTTP links cannot be reconciled from the exported files alone; a full excluded-link export is recommended in Section 10 of the report.

## Integrity

Run `sha256sum -c SHA256SUMS` from the bundle root to verify the files.
