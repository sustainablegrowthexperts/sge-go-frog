# Deterministic Crawler Audit vs Existing Auditor

**Sites compared:** `www.assuranceskin.com`, `sustainable-growth-experts.com`

**Inputs**

- New deterministic tool output: `misc/sample-audits.zip` (files dated 2026-10-29)
- Existing auditor output: `crawls/www-assuranceskin-com-74743b7697f7/` and `crawls/sustainable-growth-experts-com-ce34620f6bc1/` (September 2026)

**Method**

- Compared pages, content links, unique source -> target pairs, link occurrences, anchors, orphans, and block decisions.
- URLs were normalized for scheme, `www.`, duplicate slashes, and trailing slash before comparison.
- Ambiguous old-only links were checked against the live sites on 2026-10-29 to separate tool differences from site edits.
- No tool code, crawl data, or source files were modified.

---

## 1. Bottom line

### sustainable-growth-experts.com

The content link graph is effectively identical after URL normalization: **9 old content links vs 9 new**, same source/target/anchor triples. No content links were missed.

Differences are housekeeping/classification improvements:

- Old auditor crawled 5 `.mp4` files as pages; new auditor does not.
- Old auditor kept both `/contact-us` and `/contact-us/`; new auditor collapses them.
- New auditor separates 11 self-links into `self_links` instead of leaving them in nav.
- Orphans are the same after normalization (3 pages), because old counted the trailing-slash duplicate as a fourth orphan.

The one remaining SGE issue is that **5 of the 9 new "content" links are `.mp4` media files**, not HTML pages. They should not be treated as content pages for an internal linking audit.

### www.assuranceskin.com

The new tool finds **more real content links** than the old auditor: 836 unique source -> target pairs vs 779 old, and 1,078 occurrences vs 1,030 old. Most of the new-only links are old-auditor false negatives, especially the homepage and service pages that the old tool over-excluded.

However, the new tool has two clear regression classes:

1. **Related-post sections misclassified as nav** on three pages: 16 unique content targets missed.
2. **Homepage/Chinese-homepage blog carousels misclassified as nav**: 6 unique targets / 12 occurrences missed.

It also has canonical/redirect and asset-accounting issues that distort inbound counts, orphans, and PageRank.

The agentic baseline findings (orphans, PageRank, anchor patterns, exclusions) are recorded with artifact references in **Section 3**; the deterministic cross-references appear in Sections 4-10.

### Reconciliation of the 30 unique links present in old but not new

| Cause | Unique links | Verdict |
|---|---:|---|
| Related-post blocks labeled nav by new tool | 16 | **Genuine new-tool misses** |
| Self-links now excluded by new tool | 5 | Correct; old counted self-links as content |
| Site copy changed links from `/about-us` to homepage | 8 | Site drift, not a tool miss |
| Old `/cn/medical-dermatology/eczema` redirect alias | 1 | Redirect handling difference, not a real page miss |
| **Total** | **30** | |

### Reconciliation of the 87 unique links present in new but not old

| Source page | Unique new-only links | Main reason |
|---|---:|---|
| Homepage `/` | 54 | Old tool over-excluded homepage content |
| `/aesthetic-dermatology/stellar-m22-opt-optima-ipl` | 9 | Old tool over-excluded a large page block |
| `/medical-dermatology/eczema-treatment-singapore` | 7 | Old tool over-excluded a large page block |
| `/medical-dermatology/covid-19-and-skin-problems-a-dermatologists-guide` | 3 | Old tool undercounted article links |
| New haze article | 3 | Page did not exist in old crawl |
| `/surgical-dermatology` | 2 | Old tool undercounted overview links |
| `/cn/medical-dermatology/hair-loss` | 2 | Old tool undercounted related-post links |
| `/privacy-policy` | 2 | Page did not exist in old crawl |
| Five single-link pages | 5 | Mostly old-tool false negatives / new page |
| **Total** | **87** | |

---

## 2. High-level metrics

> Old block/block-count metrics are not directly comparable because the old auditor only exported blocks that needed review; the new tool exports all blocks.

| Metric | SGE old | SGE new | Askin old | Askin new |
|---|---:|---:|---:|---:|
| Pages | 14 | 8 | 161 | 159 |
| Content link occurrences | 9 | 9 | 1,030 | 1,078 |
| Unique content source -> target pairs | 9 | 9 | 779 | 836 |
| Orphans (as exported) | 4 | 3 | 9 | 8 |
| Orphans (normalized URLs) | 3 | 3 | 9 | 8 |
| Nav links | 100 | 80 | 22,648 | 22,239 |
| Self-links | not separated | 11 | not separated | 436 |
| Repeated/boilerplate links | 0 | 0 | 267 | 97 |
| External links | 45 | 32 | 1,096 | 922 |
| Non-HTTP links | 0 | 0 | 1,397 | 1,377 |
| Blocks exported | 2 candidates | 5 | 150 decisions | 500 |
| Top PageRank | 0.0737 | 0.137006 | 0.047262 | 0.052821 |

Notes:

- SGE page count drops from 14 to 8 because 5 media files and 1 trailing-slash duplicate are removed.
- Askin page count drops from 161 to 159 because 4 redirect URLs are no longer pages, while 2 new pages (`haze...`, `privacy-policy`) are added.
- Nav/self/repeated counts are not directly comparable because the new tool separates self-links and applies repeated-block logic after nav exclusion.

---

## 3. Agentic baseline findings (reference)

The agentic auditor's findings below are derived from its exported artifacts, primarily `link_graph.json` (keys `orphans`, `pagerank_ranking`, `links`, `pages`, `excluded`) and `block_decisions.json`. These are the baseline findings that the deterministic output should either reproduce or intentionally change.

### 3.1 Orphaned pages

| Site | Agentic orphan count | Agentic orphans and nav-inbound status |
|---|---:|---|
| SGE | 4 exported / 3 unique | `contact-us` (nav 9), `contact-us/` (nav 1), `cro/` (nav 9), `fb-ads/` (nav 9). All are nav-reachable but content-orphaned; the two `contact-us` forms are the same page. |
| Askin | 9 | `/blog/` (nav 285), `cn/aesthetic-dermatology/virtue-rf-microneedling-treatment-singapore/` (134), `cn/medical-dermatology/exosome-hair-loss-treatment-singapore/` (136), `cn/surgical-dermatology/e-filing-for-skin-surgery-in-singapore/` (134), `cn/uncategorized-cn/covid-19-and-skin-problems-a-dermatologists-guide/` (3), `cn/uncategorized-cn/eczema-faq/` (3), `cn/uncategorized-cn/eczema-in-asians-everything-you-need-to-know/` (3), `/our-clinic/` (192), `/products/` (351). All are nav-reachable but content-orphaned. |

Source: `crawls/sustainable-growth-experts-com-ce34620f6bc1/link_graph.json` and `crawls/www-assuranceskin-com-74743b7697f7/link_graph.json`, keys `orphans` and `pages[].nav_inbound`.

Deterministic cross-reference: Section 8.3. SGE matches after trailing-slash dedupe. Askin drops `/blog` and `cn/.../exosome` from the orphan list, adds `/privacy-policy`, and removes redirect URLs from the page set.

### 3.2 Internal PageRank / link-juice distribution

**SGE agentic baseline**

- Top PageRank: `0.073700` for `healthcare-google-ads`, `healthcare-seo`, `tiktok-ads-for-healthcare`, `website-design`, and `SGE-Services-ContentMarketing.mp4`, each with `content_inbound: 1`.
- Bottom PageRank: `0.067340` for `/`, both `contact-us` variants, `cro`, and `fb-ads`, each with `content_inbound: 0`.
- Top-page share: **7.37%**.
- The dead heat is caused by 5 of the 9 content links pointing at `.mp4` files and the remaining 4 pointing at the four service pages.

**Askin agentic baseline**

| Rank | URL | PageRank | Content inbound |
|---:|---|---:|---:|
| 1 | `/` | 0.047262 | 48 |
| 2 | `/medical-dermatology/acne-treatment-singapore/` | 0.029055 | 15 |
| 3 | `/cn/` | 0.023551 | 18 |
| 4 | `/about-us/` | 0.023440 | 25 |
| 5 | `/aesthetic-dermatology/acne-scar-removal-and-treatment/` | 0.021325 | 15 |

- Bottom PageRank: `0.001639` for `cn/.../exosome-hair-loss`, `cn/.../e-filing`, `cn/.../covid-19`, `cn/.../eczema-faq`, and `cn/.../eczema-in-asians`, all with `content_inbound: 0`.
- Top-page share: **4.75%**.

Source: both `link_graph.json` files, key `pagerank_ranking`.

Deterministic cross-reference: Section 8.4. The new top shares are **13.70%** (SGE) and **5.28%** (Askin); the differences come from node-set, self-link, media, and redirect handling, not from a like-for-like PageRank run.

### 3.3 Anchor text patterns

**SGE agentic baseline**

- Top anchor: `Learn More` (4 occurrences, 4 distinct targets).
- The other 5 content anchors are raw `.mp4` URLs, e.g. `https://.../SGE-Services-SEO.mp4`.
- Generic anchors (`click here`, `read more`, `here`, `this`): **0**.
- Empty/image-only anchors: **0**.
- `rel` usage (`nofollow`, `sponsored`, `ugc`): **0**.
- Over-optimization pairs (same anchor -> same target from 3+ distinct sources): **0**.

**Askin agentic baseline**

- Top anchors: `Read More` (163), `阅读更多` (130), `dermatologist in Singapore` (13), `皮肤科医生` (13), `了解更多` (12), `dermatologist` (12), `[image]` (11).
- Generic anchors: **163** (`Read More`).
- Image-only/empty anchors: **102**.
- `rel` usage: **0**.
- Over-optimization pairs (3+ distinct sources): **65**.

Top over-optimization examples from the agentic links:

| Anchor | Target | Distinct sources |
|---|---|---:|
| `dermatologist in Singapore` | `/` | 13 |
| `皮肤科医生` | `/cn/` | 12 |
| `了解更多` | `/cn/about-us/` | 9 |
| `dermatologist` | `/` | 9 |
| `cryotherapy` | `/surgical-dermatology/cryotherapy-liquid-nitrogen-treatment/` | 9 |
| `阅读更多` | `cn/.../stellar-m22-opt-optima-ipl/` | 8 |
| `Dr. Wong` | `/about-us/` | 6 |
| `Adult Acne: Facts or Fictions` | `/medical-dermatology/top-facial-concerns-treatment-preferences-for-women/` | 6 |

Source: both `link_graph.json` files, key `links[].anchor`; agentic generic set is `click here`, `read more`, `here`, `this`.

Deterministic cross-reference: Section 9. The new tool reports `Read More` 158, `阅读更多` 132, image/empty 96, and 20 over-optimization entries (top 20 capped). The small count differences are mostly site copy updates and duplicate-block suppression; the image-alt handling is better in the new tool.

### 3.4 Structural breakdown / exclusions

| Metric | SGE agentic | Askin agentic |
|---|---:|---:|
| Content links | 9 | 1,030 |
| Nav-container links excluded | 100 | 22,648 |
| Repeating-boilerplate links excluded | 0 | 267 |
| LLM-excluded links | 2 | 182 |
| External links excluded | 45 | 1,096 |
| Out-of-scope links excluded | 0 | 0 |
| Non-HTTP links excluded | 0 | 1,397 |
| Blocks adjudicated by agent | 2 | 150 |
| Links in content-decided blocks | 9 | 16 |
| Parent tags | `video` 5, `div` 4 | `div` 466, `p` 282, `li` 253, `span` 10, `h4` 10, `strong` 7, `em` 2 |
| Canonical root | `https://sustainable-growth-experts.com/` | `https://www.assuranceskin.com/` |

Source: both `link_graph.json` files, keys `links`, `excluded`, `repeating_block_count`, `llm_decisions_applied`, `llm_decided_content_links`, `canonical_root`.

Deterministic cross-reference: Section 2. The new tool reports 9 / 1,078 content links, 80 / 22,239 nav links, 11 / 436 self-links, 0 / 97 boilerplate links, 32 / 922 external links, and 0 / 1,377 non-HTTP links. The difference in excluded counts is not fully reconcilable without the full excluded-link export requested in Section 10.

### 3.5 Agentic block adjudication

| Site | Decisions applied | Content | Nav | Boilerplate |
|---|---:|---:|---:|---:|
| SGE | 2 | 1 (`blk_40de11612230`, `tab-panel`) | 1 (`blk_d6b8a1a6568e`, `page-template`) | 0 |
| Askin | 150 | 1 | 147 | 2 |

Source: `crawls/*/block_decisions.json`, key `decisions`.

This is important context for the old-vs-new differences: on Askin the agent overwhelmingly confirmed nav classifications (147 of 150). The old auditor's false negatives on the homepage, `stellar-m22`, `eczema-treatment`, and the article pages came from its upstream block heuristics, not from a large set of agent "content" overrides.

### 3.6 Agentic headline actions

These are the actions implied by the agentic findings:

- **SGE:** add content links to the 3 unique orphan pages (`contact-us`, `cro`, `fb-ads`); stop treating `.mp4` files as content-link peers; replace four `Learn More` anchors with descriptive anchors.
- **Askin:** add content links to the 9 orphan pages (especially `/products`, `/our-clinic`, `/blog`, and the 5 CN pages); reduce the 163 `Read More` and 102 image-only anchors; review the 65 over-optimization pairs, starting with `dermatologist in Singapore` -> `/` (13 sources), `皮肤科医生` -> `/cn` (12), and `了解更多` -> `/cn/about-us` (9).

---

## 4. Genuine misses / undercounts in the new tool

### 4.1 Related-post sections misclassified as nav (highest-priority bug)

Three blocks with the same semantic role were labeled `nav`:

| Block | Page | Links | New decision | New reason |
|---|---|---:|---|---|
| `blk_609c182df95d` | `/aesthetic-dermatology/acne-scar-removal-and-treatment` | 6 | nav | `outside_main_high_nav_score` |
| `blk_93f6341be3a9` | `/medical-dermatology/acne-treatment-singapore` | 10 | nav | `outside_main_high_nav_score` |
| `blk_1e2cb7cc8277` | `/aesthetic-dermatology/pigmentation-treatment-singapore` | 16 | nav | `outside_main_high_nav_score` |

All three are `div.columns recent-posts-body`, i.e. the "Read More" related-post section at the bottom of service pages. The same block class appears **89 times as content**, 3 times as nav, and 1 time as boilerplate. This is inconsistent classification, not a site-structure difference.

**Impact:** 16 unique content targets are missing from the new audit:

- Acne Scar Removal: 3 targets
- Acne Treatment: 5 targets
- Pigmentation Treatment: 8 targets

**Examples (verified still present on the live site):**

- `acne-scar-removal-and-treatment` -> `virtue-rf-microneedling-treatment-singapore` via "Read More"
- `acne-scar-removal-and-treatment` -> `helios-iii-acne-pigment-laser` via "Read More"
- `pigmentation-treatment-singapore` -> `melasma` via "Read More"
- `pigmentation-treatment-singapore` -> `facial-spots-removal` via "Read More"
- `acne-treatment-singapore` -> `stellar-m22-opt-optima-ipl` via "Read More"

The live pages still contain the `section recent-posts-section` block and these links, so this is a new-tool false negative.

### 4.2 Homepage / Chinese-homepage blog carousels misclassified as nav

| Block | Page | Links | New decision | New reason |
|---|---|---:|---|---|
| `blk_6014aa683de2` | `/` | 6 | nav | `high_nav_score_no_main` |
| `blk_75e5db25d09c` | `/cn` | 6 | nav | `high_nav_score_no_main` |

These are `ul.blog-slider` "latest posts" carousels in page content. The same class appears **20 times as content**, 3 times as nav, and 4 times as boilerplate.

**Impact:** 6 unique targets / 12 link occurrences missed:

- Homepage: `top-facial-concerns-treatment-preferences-for-women`, `what-you-need-to-know-about-mole-removal`, `viral-warts-the-illegal-immigrants-on-our-skin`
- CN homepage: `cn/uncategorized-cn/adult-acne-facts-or-fictions`, `what-you-need-to-know-about-mole-removal`, `viral-warts-the-illegal-immigrants-on-our-skin`

A third blog-slider block (`blk_76d18ba5cb0c`, blog index, 16 links) is also labeled nav, but all of its targets are still captured by other content blocks, so it only changes duplicate counts, not coverage.

### 4.3 Repeated-signature boilerplate can over-delete legitimate links

The new tool labels 6 blocks as `boilerplate` due to repeated signatures:

- 4 `ul.blog-slider` blocks (page_count 2-4)
- 1 `div.columns recent-posts-body` block (page_count 2)
- 1 `div.about_info` block (page_count 28)

In the blog-index case this only removes duplicate carousel links: blog post inbound occurrence counts drop by 2 per post (e.g. `hifu-treatment-cost-in-singapore` 5 -> 3) while unique source -> target coverage is unchanged.

However, the rule is risky for content blocks. If a legitimate related-post block happens to repeat on two article pages, all its links are removed from both pages. A safer design is:

- Mark the block `repeated` and report it,
- keep the links but count them once per site or with a lower weight,
- only auto-exclude when the repeated block is also nav/footer-like or appears on non-content pages.

### 4.4 Differences that are not new-tool misses

These old-only links should **not** be treated as regressions:

- **Self-links (5):** old counted `melasma -> melasma`, `ota-nevus -> ota-nevus`, `allergy -> allergy`, `biologics -> biologics`, and `cn/anti-wrinkle -> self`. New excludes 436 self-links overall, which is correct for link-equity analysis.
- **Site drift (8):** old links to `/about-us` now point to `/` in the live site, e.g. `chemical-peeling`, `hives`, `eczema-faq`, `lip-pigmentation`, `viral-warts`. Verified live; new output matches the current site.
- **Redirect alias (1):** old `/cn/medical-dermatology/eczema` is a redirect to `/medical-dermatology/eczema-treatment-singapore`; new correctly treats the old URL as a redirect rather than a page.

---

## 5. Miscategorization / heuristic issues

### 5.1 Content-container detection is failing on Askin

In the Askin audit:

- `page_has_content_container` is `true` for only **14 of 500 block records**.
- `content_hint` is `false` for **all 500 blocks**.
- `inside_content` is `false` for **all 500 blocks**.

The site does not use a literal `<main>` element; its content lives in wrappers such as `.theme-container`, `.content-container`, `.content-block`, `.article-content`, and `.wysiwyg-content`. Because the tool cannot identify a content container, nav heuristics such as `outside_main_high_nav_score` and `high_nav_score_no_main` fire on content blocks.

This is the root cause of both the related-post and homepage blog-carousel false negatives.

Recommended content-root selectors to try:

- `main`, `[role="main"]`, `article`
- `.theme-container`, `.content-container`
- `.content-block`, `.article-content`, `.wysiwyg-content`
- `.recent-posts-section`, `.recent-posts-body`
- `.blog-slider`

Also, if `page_has_content_container` is false, the tool should avoid making a "outside main" decision at all. A block should not become nav purely because the main detector failed.

### 5.2 Same block class gets different decisions

Examples from Askin:

| Class | Content | Nav | Boilerplate |
|---|---:|---:|---:|
| `div.columns recent-posts-body` | 89 | 3 | 1 |
| `ul.blog-slider` | 20 | 3 | 4 |
| `div.theme-container` | 101 | 2 | 0 |
| `div.article-content` | 10 | 0 | 0 |

This is not inherently wrong because identical classes can appear in different contexts, but the current distribution shows the nav heuristic is overriding clear content semantics. A class/content-ancestor allowlist or a "content evidence" score that can veto nav would fix most of this.

### 5.3 Nav detection itself is otherwise good

No Askin content block was labeled content while also carrying a nav marker or an obviously nav-like class (`nav`, `menu`, `header`, `footer`, `breadcrumb`, `submenu`, `metismenu`). The new tool also correctly handles deeply nested menus: on the `stellar-m22` page, a 176-link `theme-container` block is content at the block level, but only its 10 real content links survive at the link level.

So the problem is not that nav is under-detected; it is that content is sometimes mistaken for nav when the main-container signal is missing.

---

## 6. URL canonicalization and redirect handling

### 6.1 Canonical host is internally inconsistent

Observed in the Askin audit:

- `start_url`: `https://www.assuranceskin.com/`
- `canonical_root`: `https://assuranceskin.com/`
- Page keys: `https://assuranceskin.com/...`
- Every page `final_url`: `https://www.assuranceskin.com/...`

So the exported page URL is the non-`www` URL, but the real final URL is `www`, and all non-`www` URLs 301 to `www`. This makes exported URLs noisy and can split counts if any link uses the `www` form.

Recommendation: use the final response URL as the canonical page key, keep a separate alias map (`raw_url`, `aliases`, redirect source -> target), and export the canonical URL in reports.

### 6.2 Redirect targets are not resolved for inbound counting

62 Askin content links point at redirect URLs. Most are homepage links to `https://assuranceskin.com/`, which is a 301 to `www`; because the page key is also the non-`www` root, those counts still land on the page.

The problem is the non-root redirect aliases:

| Redirect target | Final page | Content links credited to alias |
|---|---|---:|
| `/cn/medical-dermatology/eczema` | `/medical-dermatology/eczema-treatment-singapore` | 2 |
| `/cn/medical-dermatology/hair-loss-old-v2` | `/cn/medical-dermatology/hair-loss` | 2 |
| `/aesthetic-dermatology/m22-optimal-pulse-therapy-opt` | `/aesthetic-dermatology/stellar-m22-opt-optima-ipl` | 1 |

These links are counted against a redirect URL that is not in `pages`, so the final page never receives the inbound credit. This distorts content inbound counts, PageRank, and potentially orphan detection.

Recommendation: resolve every internal target through the redirect map before counting inbound/outbound, PageRank edges, and orphan status.

### 6.3 Non-page and broken targets are counted as content

There are 9 Askin content links to internal URLs that are not in the page set:

- 5 to non-root redirect aliases (above)
- 3 to `https://assuranceskin.com/?page_id=5430`, which currently returns 404
- 1 to `/cn/home`, which redirects to `/`

The `?page_id=5430` links are not flagged as broken; they become dangling content nodes. The audit should have a link-health/status column for internal targets and should distinguish page targets from redirects, assets, and broken URLs.

For SGE, all 5 non-page content targets are `.mp4` files, not broken links.

---

## 7. Asset and non-HTML links

SGE is the clearest example:

- Old auditor crawled 5 `.mp4` files as pages.
- New auditor correctly stops crawling them as pages.
- But new auditor still counts 5 `.mp4` links as content links.

Result: **5 of 9 SGE content links (56%) are media files**, and the PageRank node set includes media targets with no outgoing links. This makes the SGE link graph look smaller and more concentrated than it really is.

Recommendation:

- Add a distinct `asset`/`file` category for `.mp4`, `.pdf`, `.jpg`, `.png`, `.zip`, etc.
- Keep them reportable as "content links to assets" if useful, but exclude them from HTML content inbound/outbound, PageRank, orphan calculations, and page counts.
- Do the same for `?page_id=...` and other non-canonical query URLs if they resolve to a real page.

---

## 8. Counting, orphans, and PageRank

### 8.1 Occurrences vs unique links

The new audit counts link occurrences. A blog card with an image link and a title link produces two links to the same target. This is consistent with the old auditor but makes inbound counts harder to interpret.

For Askin:

- 1,078 content occurrences
- 836 unique source -> target pairs

Recommendation: report both `occurrences` and `unique_source_target_links` for page inbound/outbound, and make the primary ranking metric explicit.

### 8.2 Orphan logic is direct-inbound only, not reachability

`is_orphan` is effectively `content_inbound == 0 && !is_start`. That allows an orphan page to "rescue" another page.

Askin example:

- `/privacy-policy` is content-orphaned (only footer/nav links).
- `/privacy-policy` links to `/blog` in its body.
- New audit therefore marks `/blog` as not orphaned, even though the only content path to `/blog` is through another orphan.

Recommended:

- Keep the current content-orphan metric.
- Add a true reachability metric: BFS from the start URL through content links only.
- Report `content_orphan`, `nav_reachable`, and `content_reachable_from_start` separately.

### 8.3 Askin orphan differences are explainable

- `/blog`: old orphan, new not orphan because new crawled `/privacy-policy` and that page links to the blog. This is a reachability-chain issue, not necessarily a link improvement.
- `/cn/medical-dermatology/exosome-hair-loss-treatment-singapore`: old orphan, new not orphan because new found two content links from `/cn/medical-dermatology/hair-loss` that old missed.
- `/privacy-policy`: new orphan only; page was not in the old crawl.

### 8.4 PageRank is not directly comparable

The page sets, self-link treatment, redirect handling, and dangling-node treatment differ. Example top values:

- SGE: old top PageRank 0.0737, new top share 0.137006.
- Askin: old top PageRank 0.047262, new top share 0.052821.

The new tool also appears to include non-page targets (media, redirect aliases, 404 query URLs) as PageRank nodes. Recommendation: document the node set, edge deduplication, dangling-node redistribution, and whether asset/redirect aliases are included.

---

## 9. Anchor extraction

The new tool improves anchor handling in several ways:

- Image alt text is preserved as `[image: alt]`; empty alt remains `[image]`.
- Non-breaking spaces are normalized: old `freckles\u00a0and superficial\u00a0melasma` -> new `freckles and superficial melasma`.
- 9 common source -> target pairs have different anchor sets. Most differences are site copy updates (e.g. "eczema dermatologist" -> "eczema specialist") or removal of a duplicate carousel block, not anchor-extraction bugs.

Recommendation: export both `raw_anchor` and normalized anchor text, and retain the block ID/signature for each link so anchor changes can be traced to a block decision.

---

## 10. Reporting and observability gaps

The new output is harder to audit than the old output in several ways:

1. **No full link inventory.** `audit-links.csv` contains only content links. There is no export of nav, self, boilerplate, external, non-HTTP, or out-of-scope links with source/target/anchor/reason. The counts cannot be reconciled or spot-checked.
2. **No excluded-link reasons at link level.** We can see aggregate `excluded` counts but not which links were excluded or by which rule.
3. **Blocks lack signature, anchors, and snippet.** The old `block_candidates.json` included anchors, snippet, and block signature. New blocks only include aggregate features and a decision. This makes it impossible to verify why a block became nav/boilerplate from the audit file alone.
4. **`auto_label`, `auto_excluded`, and `effective_label` are null.** They appear in the schema but are not populated in the output. Either populate them or remove them.
5. **`content_hint` and `inside_content` are always false on Askin.** These look like dead fields in the current output.
6. **No crawl failure/cancellation list in `audit.json`.** If pages fail, the report does not expose them.
7. **External/non-HTTP counts differ from the old audit** (SGE 45 -> 32 external; Askin 1,096 -> 922 external, 1,397 -> 1,377 non-HTTP) with no list to explain the difference.

Recommendation: add a full `links-all.csv` (or raw JSON) with `decision`, `reason`, `block_id`, `block_signature`, `anchor`, `context`, `target_status`, and `target_type` for every discovered link.

---

## 11. Prioritized refinement list

### P0 - correctness

1. **Fix content-container detection and prevent nav overrides.**
   - Detect `main`, `[role=main]`, `article`, `.theme-container`, `.content-container`, `.content-block`, `.article-content`, `.wysiwyg-content`, `.recent-posts-section`, `.blog-slider`.
   - If no content container is found, do not use "outside main" as a nav reason.
   - Add a content-evidence veto: blocks with content-class tokens (`recent-posts`, `article`, `content`, `blog-slider`, `wysiwyg`) should not be auto-labeled nav solely by position/nav score.
   - Expected fix: 16 related-post links + 6 homepage blog-carousel links.

2. **Resolve redirects before counting.**
   - Use `final_url` as the canonical page key.
   - Build alias -> final mapping and apply it to link targets before inbound, PageRank, and orphan calculations.
   - Expected fix: 5 Askin links currently credited to redirect aliases.

### P1 - classification and reporting

3. **Separate assets from pages.**
   - Add `asset`/`file` target type; exclude `.mp4`, `.pdf`, image files, etc. from content link counts, PageRank, and orphans.
   - Expected fix: SGE content link count should be 4 page links, not 9.

4. **Export all links and block evidence.**
   - Full link inventory with decision/reason.
   - Block signature, anchors, snippet, sample pages, and source count.
   - Target status (200/301/404) and target type (page/asset/redirect/external).

5. **Add reachability-based orphan reporting.**
   - Keep `content_inbound == 0`.
   - Add BFS `content_reachable_from_start`.
   - Do not let an orphan page clear another page's orphan status.

### P2 - reporting quality

6. **Report occurrences and unique source -> target links separately.**
7. **Handle repeated content blocks conservatively.**
   - Mark repeated, but do not delete all links unless the block is nav/footer-like or appears on non-content pages.
   - Report how many links/unique targets were suppressed.
8. **Document PageRank methodology** (node set, unique edges, dangling redistribution, asset/alias handling).
9. **Fix or remove dead block fields** (`content_hint`, `inside_content`, null `auto_label`/`auto_excluded`/`effective_label`).
10. **Flag broken internal links** (e.g. `?page_id=5430` 404) and internal redirect targets.
11. **Reconcile external/non-HTTP counts** by exporting those link lists with reasons.

---

## 12. What the new tool already does better

These differences are improvements and should be preserved:

- Excludes self-links from content/link-equity counts (436 on Askin).
- Collapses trailing-slash duplicates and `www`/non-`www` duplicates (SGE pages 14 -> 8; Askin redirect URLs removed from pages).
- Lists redirects explicitly instead of treating them as ordinary pages.
- Handles deeply nested nav correctly: nested menu links are excluded even when the outer block is marked content.
- Preserves image alt text in anchors.
- Normalizes whitespace in anchors.
- Finds real content links the old tool missed, especially on the homepage, service overview pages, and articles.
- Exports block-level decisions with reasons (`nav_marker`, `outside_main_high_nav_score`, `repeated_signature`, etc.), which is a good foundation for deterministic tuning.

---

## 13. Appendix: largest Askin page-level content outbound changes

| Page | Old | New | Difference | Main cause |
|---|---:|---:|---:|---|
| `/` | 0 | 56 | +56 | Old tool over-excluded homepage content |
| `/aesthetic-dermatology/stellar-m22-opt-optima-ipl` | 0 | 10 | +10 | Old tool over-excluded large block |
| `/medical-dermatology/eczema-treatment-singapore` | 1 | 8 | +7 | Old tool undercounted article links |
| `/medical-dermatology/haze-...` | 0 | 3 | +3 | New page in new crawl |
| `/cn/medical-dermatology/hair-loss` | 0 | 3 | +3 | Old tool undercounted related posts |
| `/blog` | 91 | 79 | -12 | Duplicate carousel block suppressed; unique targets still covered |
| `/aesthetic-dermatology/pigmentation-treatment-singapore` | 8 | 0 | -8 | Related posts labeled nav |
| `/medical-dermatology/acne-treatment-singapore` | 5 | 0 | -5 | Related posts labeled nav |
| `/aesthetic-dermatology/acne-scar-removal-and-treatment` | 3 | 0 | -3 | Related posts labeled nav |
| `/aesthetic-dermatology/melasma` | 9 | 7 | -2 | Self-link + site drift |
| `/aesthetic-dermatology/ota-nevus-and-horis-macule` | 3 | 2 | -1 | Self-link |
| `/medical-dermatology/allergy` | 10 | 9 | -1 | Self-link |
| `/medical-dermatology/eczema-faq` | 9 | 8 | -1 | Site drift (`/about-us` -> `/`) |
| `/medical-dermatology/hives` | 6 | 5 | -1 | Site drift (`/about-us` -> `/`) |

---

## 14. References and bundle manifest

### Agentic references

| Site | Artifact | Used for |
|---|---|---|
| SGE | `agentic/sustainable-growth-experts.com/link_graph.json` | Pages, content links, orphans, PageRank, anchors, exclusions |
| SGE | `agentic/sustainable-growth-experts.com/block_decisions.json` | Agent block adjudication (2 decisions) |
| SGE | `agentic/sustainable-growth-experts.com/block_candidates.json` | Candidate block features, anchors, snippets |
| Askin | `agentic/www.assuranceskin.com/link_graph.json` | Pages, content links, orphans, PageRank, anchors, exclusions |
| Askin | `agentic/www.assuranceskin.com/block_decisions.json` | Agent block adjudication (150 decisions) |
| Askin | `agentic/www.assuranceskin.com/block_candidates.json` | Candidate block features, anchors, snippets |

The original agentic `crawl_raw.json` files are intentionally not bundled because they are large (about 62 MB for Askin) and are not needed for the findings above. They remain in the workspace crawl directories if raw-link reproduction is required.

### Deterministic references

| Site | Artifact | Used for |
|---|---|---|
| SGE | `deterministic/sustainable-growth-experts.com/audit.json` | Pages, content links, orphans, PageRank, blocks, anchors, redirects |
| SGE | `deterministic/sustainable-growth-experts.com/audit-pages.csv` | Page-level audit view |
| SGE | `deterministic/sustainable-growth-experts.com/audit-links.csv` | Content-link audit view |
| SGE | `deterministic/sustainable-growth-experts.com/audit-blocks.csv` | Block decisions and features |
| Askin | `deterministic/www.assuranceskin.com/audit.json` | Pages, content links, orphans, PageRank, blocks, anchors, redirects |
| Askin | `deterministic/www.assuranceskin.com/audit-pages.csv` | Page-level audit view |
| Askin | `deterministic/www.assuranceskin.com/audit-links.csv` | Content-link audit view |
| Askin | `deterministic/www.assuranceskin.com/audit-blocks.csv` | Block decisions and features |

The deterministic files were extracted from the original `misc/sample-audits.zip` (2026-10-29).

### Live-site verification

Ambiguous old-only links were checked against the live sites on 2026-10-29. The most important checks were:

- `https://www.assuranceskin.com/aesthetic-dermatology/chemical-peeling/` now links `experienced dermatologist` to `/`, not `/about-us/`.
- `https://www.assuranceskin.com/medical-dermatology/hives/`, `eczema-faq/`, `lip-pigmentation/`, and `viral-warts-.../` now link dermatologist mentions to `/`, not `/about-us/`.
- Related-post `Read More` links on `acne-scar-removal-and-treatment/`, `pigmentation-treatment-singapore/`, and `acne-treatment-singapore/` are still present on the live pages.
- `https://www.assuranceskin.com/?page_id=5430` returns HTTP 404.

### Bundle layout

```
audit-comparison-bundle/
  deterministic-audit-comparison.md   (this report)
  README.md                           (manifest + how to read)
  agentic/
    sustainable-growth-experts.com/
    www.assuranceskin.com/
  deterministic/
    sustainable-growth-experts.com/
    www.assuranceskin.com/
```
