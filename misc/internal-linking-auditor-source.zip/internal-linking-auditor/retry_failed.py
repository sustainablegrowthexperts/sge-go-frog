#!/usr/bin/env python3
"""Retry previously-failed URLs in an existing crawl and merge the results.

Re-fetches only the URLs recorded in crawl_raw.json's "failed" list, BFS-discovers
any newly reachable in-scope pages (up to --depth from each seed), merges the new
pages/links/blocks back into crawl_raw.json, and re-runs finalize(). The rest of
the crawl is reused as-is; no full re-crawl.

    ./.venv/bin/python3 retry_failed.py --url https://example.com \
        --crawl-dir crawls/<domain-hash> \
        --apply-decisions crawls/<domain-hash>/block_decisions.json
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from urllib.parse import urljoin, urlsplit

import httpx
from bs4 import BeautifulSoup

import internal_link_crawler as ilc


def parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Retry failed URLs from an existing crawl and merge results.",
    )
    parser.add_argument("--url", required=True, help="Start URL of the original crawl.")
    parser.add_argument("--crawl-dir", required=True, help="Existing crawl directory.")
    parser.add_argument(
        "--apply-decisions",
        metavar="PATH",
        help="Block-decision JSON to apply after merging.",
    )
    parser.add_argument(
        "--depth", type=int, default=3, help="Max discovery depth from each seed."
    )
    parser.add_argument("--max-pages", type=int, default=400, help="Total page cap.")
    parser.add_argument("--delay", type=float, default=0.0, help="Delay between requests.")
    parser.add_argument("--timeout", type=float, default=20.0, help="Per-request timeout.")
    parser.add_argument(
        "--user-agent",
        default="InternalLinkAuditor/1.0 (+https://example.com/bot)",
        help="HTTP User-Agent header.",
    )
    parser.add_argument("--insecure", action="store_true", help="Disable TLS verify.")
    parser.add_argument(
        "--candidates-limit", type=int, default=150, help="Max ambiguous blocks emitted."
    )
    return parser.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)
    start_url = ilc.normalize_url(args.url)
    root = ilc.canonical_root(start_url)
    netloc = urlsplit(start_url).netloc
    site_dir = Path(args.crawl_dir).resolve()
    html_dir = site_dir / "html"
    html_dir.mkdir(parents=True, exist_ok=True)

    raw_path = site_dir / "crawl_raw.json"
    raw = json.loads(raw_path.read_text(encoding="utf-8"))
    pages: dict[str, dict] = raw["pages"]
    raw_links: list[dict] = raw["links"]
    stats: dict = raw.get("stats", {})
    blocks: dict[str, dict] = raw.get("blocks", {})
    old_failed: list[dict] = raw.get("failed", [])

    failed_urls = [item["url"] for item in old_failed]
    if not failed_urls:
        json.dump({"ok": True, "message": "No failed URLs to retry."}, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 0

    seen: set[str] = set(pages.keys())
    queue: list[tuple[str, int]] = [(url, 1) for url in failed_urls]
    headers = {"User-Agent": args.user_agent, "Accept": "text/html,*/*;q=0.8"}

    recovered: list[str] = []
    still_failed: list[dict] = []

    with httpx.Client(
        follow_redirects=True,
        timeout=args.timeout,
        headers=headers,
        verify=not args.insecure,
    ) as client:
        while queue:
            url, depth = queue.pop(0)
            if url in seen:
                continue
            seen.add(url)
            if len(pages) >= args.max_pages:
                break
            if args.delay > 0:
                time.sleep(args.delay)

            try:
                response = client.get(url)
                response.raise_for_status()
                html = response.content
                final_url = ilc.normalize_url(str(response.url))
            except Exception as exc:  # noqa: BLE001 - report and continue
                still_failed.append({"url": url, "error": str(exc)})
                continue

            file_path = html_dir / ilc.html_filename(url)
            file_path.write_bytes(html)

            soup = BeautifulSoup(response.text, "lxml")
            page_discovered: set[str] = set()

            for anchor in soup.find_all("a", href=True):
                href = (anchor.get("href") or "").strip()
                if not href or href.startswith("#"):
                    continue
                lowered = href.lower()
                if any(lowered.startswith(scheme) for scheme in ilc.SKIP_SCHEMES):
                    stats["non_http"] = stats.get("non_http", 0) + 1
                    continue

                absolute = ilc.normalize_url(urljoin(final_url, href))
                target_parts = urlsplit(absolute)
                if target_parts.scheme not in ("http", "https"):
                    stats["non_http"] = stats.get("non_http", 0) + 1
                    continue
                if target_parts.netloc != netloc:
                    stats["external"] = stats.get("external", 0) + 1
                    continue
                if not ilc.in_scope(absolute, root):
                    stats["out_of_scope"] = stats.get("out_of_scope", 0) + 1
                    continue

                page_discovered.add(absolute)

                block = ilc.find_link_block(anchor)
                signature = ilc.block_signature(block, final_url)
                block_id = ilc.block_id_for(signature) if signature else None
                if block_id and block_id not in blocks:
                    blocks[block_id] = ilc.block_features(block, final_url, signature)

                parent = anchor.parent
                rel = anchor.get("rel") or []
                if isinstance(rel, str):
                    rel = rel.split()

                raw_links.append(
                    {
                        "source": url,
                        "target": absolute,
                        "anchor": ilc.anchor_text(anchor),
                        "parent_tag": getattr(parent, "name", None),
                        "parent_id": parent.get("id") if parent else None,
                        "parent_class": (
                            " ".join(parent.get("class"))
                            if parent and parent.get("class")
                            else None
                        ),
                        "rel": rel,
                        "title": anchor.get("title"),
                        "nav_excluded": ilc.is_nav_excluded(anchor),
                        "block_signature": list(signature) if signature else None,
                        "block_id": block_id,
                    }
                )

            pages[url] = {
                "url": url,
                "final_url": final_url,
                "depth": depth,
                "status_code": response.status_code,
                "title": ilc.page_title(soup),
                "html_file": str(file_path),
                "is_start": url == start_url,
            }
            recovered.append(url)

            if depth < args.depth:
                for target in sorted(page_discovered):
                    if target not in seen:
                        queue.append((target, depth + 1))

    raw["pages"] = pages
    raw["links"] = raw_links
    raw["stats"] = stats
    raw["blocks"] = blocks
    raw["failed"] = still_failed
    raw_path.write_text(json.dumps(raw, indent=2), encoding="utf-8")

    repeated = ilc.compute_repeated(raw_links)
    candidates = ilc.build_candidates(blocks, raw_links, repeated, args.candidates_limit)
    candidates_path = site_dir / "block_candidates.json"
    candidates_path.write_text(
        json.dumps(
            {
                "start_url": start_url,
                "canonical_root": root,
                "instructions": (
                    "Label each block content | nav | boilerplate. Write "
                    "block_decisions.json as {\"<block_id>\": \"content|nav|boilerplate\"} "
                    "then re-run with --apply-decisions."
                ),
                "candidates": candidates,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    decisions: dict[str, str] = {}
    if args.apply_decisions:
        decisions = ilc.normalize_decisions(
            json.loads(Path(args.apply_decisions).read_text(encoding="utf-8"))
        )

    summary = ilc.finalize(raw, decisions, site_dir, start_url, root, netloc)
    new_block_ids = [c["block_id"] for c in candidates]
    undecided = [b for b in new_block_ids if b not in decisions]
    summary["retry"] = {
        "attempted": failed_urls,
        "recovered": recovered,
        "still_failed": still_failed,
        "new_ambiguous_blocks": len(candidates),
        "new_undecided_blocks": undecided,
    }
    summary["crawl_raw"] = str(raw_path)
    summary["block_candidates"] = str(candidates_path)
    json.dump(summary, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
