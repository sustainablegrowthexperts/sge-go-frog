#!/usr/bin/env python3
"""Export an internal-linking crawl to a Google Sheet.

Reads the `link_graph.json` produced by `internal_link_crawler.py` (plus the
site's sitemaps) and writes a structured audit workbook via the Google Sheets
API using a service-account JSON key.

Everything that varies per audit is a flag: the spreadsheet id, the crawl
directory (or a URL to derive it from), the service-account file, and the
sitemap source. Nothing is hard-coded to a particular site.

Auth:
  - Google: service account JSON (default: ./service-account.json). The target
    spreadsheet must be shared with the service account's client_email (Editor
    access). On a permission error the script prints that address so the user
    can share it and retry.

Usage:
    ./.venv/bin/python3 export_to_sheets.py \
        --spreadsheet-id <ID> --crawl-dir crawls/<domain-hash> [--url <URL>] \
        [--service-account service-account.json] [--no-sitemap] \
        [--sitemap-url <URL>] [--tabs Summary,Pages,...]

    # Preflight: verify the sheet is shared with the service account (Editor).
    ./.venv/bin/python3 export_to_sheets.py \
        --spreadsheet-id <ID> --check-access \
        [--service-account service-account.json]

  --crawl-dir     Directory containing link_graph.json (from the crawler summary).
  --url           Alternative to --crawl-dir: the crawl's start URL. The directory
                  is derived as crawls/<slug>-<hash>, matching the crawler.
  --check-access  Do not export; just confirm the sheet is reachable and editable
                  by the service account, then exit. Use this before a long crawl.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import sys
import time
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path
from urllib.parse import urljoin, urlsplit

import requests
from bs4 import BeautifulSoup

TOKEN_URI = "https://oauth2.googleapis.com/token"
SCOPE = "https://www.googleapis.com/auth/spreadsheets"
SHEETS_API = "https://sheets.googleapis.com/v4/spreadsheets"
DEFAULT_SA = Path(__file__).resolve().parent / "service-account.json"

ALL_TABS = ["Summary", "Pages", "Page Detail", "Orphans", "Sitemap Coverage"]

# Non-page assets are excluded from the Page Detail (page-to-page) view.
ASSET_EXT = (".mp4", ".mp3", ".wav", ".pdf", ".jpg", ".jpeg", ".png", ".gif",
             ".webp", ".svg", ".ico", ".css", ".js", ".zip", ".doc", ".docx",
             ".xls", ".xlsx", ".ppt", ".pptx")

GENERIC_ANCHORS = {
    "learn more", "read more", "click here", "here", "more", "this",
    "this page", "find out more", "discover more", "see more", "details",
}

# Landing/utility URL hints used only to label sitemap rows, never to exclude.
LANDING_HINTS = ("thank-you", "thank_you", "/lp", "-lp", "squeeze", "landing",
                 "contact-from", "/go/", "/offer", "get-started")
POLICY_HINTS = ("privacy", "terms", "cookie", "legal", "gdpr", "disclaimer")


class UserError(Exception):
    """A problem the user can fix (access, credentials). Printed without traceback."""


# ---------------------------------------------------------------------------
# Google auth + Sheets client
# ---------------------------------------------------------------------------

def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def service_account_email(path: Path) -> str | None:
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("client_email")
    except Exception:
        return None


def get_access_token(sa_path: Path) -> str:
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding

    try:
        sa = json.loads(sa_path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise UserError(f"Service-account file not found: {sa_path}")
    except Exception as exc:  # noqa: BLE001
        raise UserError(f"Could not read service-account file {sa_path}: {exc}")

    for key in ("client_email", "private_key"):
        if not sa.get(key):
            raise UserError(f"Service-account file {sa_path} is missing '{key}'.")

    now = int(time.time())
    header = {"alg": "RS256", "typ": "JWT"}
    claims = {"iss": sa["client_email"], "scope": SCOPE, "aud": TOKEN_URI,
              "iat": now, "exp": now + 3600}
    signing_input = (
        _b64url(json.dumps(header, separators=(",", ":")).encode())
        + "." + _b64url(json.dumps(claims, separators=(",", ":")).encode())
    )
    key = serialization.load_pem_private_key(sa["private_key"].encode(), password=None)
    sig = key.sign(signing_input.encode(), padding.PKCS1v15(), hashes.SHA256())
    assertion = signing_input + "." + _b64url(sig)

    resp = requests.post(TOKEN_URI, data={
        "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
        "assertion": assertion,
    }, timeout=30)
    if not resp.ok:
        raise UserError(f"Google token request failed ({resp.status_code}): {resp.text[:300]}")
    return resp.json()["access_token"]


class SheetsClient:
    def __init__(self, spreadsheet_id: str, token: str):
        self.base = f"{SHEETS_API}/{spreadsheet_id}"
        self.id = spreadsheet_id
        self.h = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    def _check(self, resp: requests.Response, action: str):
        if resp.ok:
            return resp.json() if resp.text else {}
        if resp.status_code in (401, 403, 404):
            email = getattr(self, "sa_email", None) or "<service-account email>"
            raise UserError(
                f"Cannot {action} (HTTP {resp.status_code}).\n\n"
                "Make sure the spreadsheet is shared with this service account as Editor:\n\n"
                f"    {email}\n\n"
                "In Google Sheets: Share -> paste that address -> Editor -> Send, "
                "then run the export again."
            )
        raise RuntimeError(f"Google Sheets {action} failed ({resp.status_code}): {resp.text[:400]}")

    def meta(self) -> dict:
        return self._check(requests.get(self.base, headers=self.h, timeout=30), "read spreadsheet")

    def batch_update(self, requests_: list) -> dict:
        return self._check(
            requests.post(f"{self.base}:batchUpdate", headers=self.h,
                          json={"requests": requests_}, timeout=60),
            "update spreadsheet")

    def clear(self, ranges: list[str]) -> dict:
        return self._check(
            requests.post(f"{self.base}/values:batchClear", headers=self.h,
                          json={"ranges": ranges}, timeout=60),
            "clear ranges")

    def write_values(self, data: list) -> dict:
        return self._check(
            requests.post(f"{self.base}/values:batchUpdate", headers=self.h,
                          json={"valueInputOption": "USER_ENTERED", "data": data}, timeout=120),
            "write values")


# ---------------------------------------------------------------------------
# Crawl discovery + sitemap
# ---------------------------------------------------------------------------

def derive_crawl_dir(url: str, base_dir: Path) -> Path:
    netloc = urlsplit(url).netloc.lower()
    slug = re.sub(r"[^a-z0-9]+", "-", netloc).strip("-") or "site"
    digest = hashlib.sha1(netloc.encode("utf-8")).hexdigest()[:12]
    return base_dir / f"{slug}-{digest}"


def _localname(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


SM_NS = "{http://www.sitemaps.org/schemas/sitemap/0.9}loc"


def _locs(xml_text: str) -> list[str]:
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return []
    out = []
    for el in root.iter():
        # Only page/sitemap <loc> entries, never <image:loc> (same local name).
        if el.tag not in (SM_NS, "loc"):
            continue
        if el.text and el.text.strip():
            out.append(el.text.strip())
    return out


def _dedupe(items: list[str]) -> list[str]:
    seen, out = set(), []
    for item in items:
        if item not in seen:
            seen.add(item)
            out.append(item)
    return out


def fetch_sitemap_urls(root_url: str, timeout: float = 20.0) -> list[str]:
    """Return every <loc> from the site's sitemap, following a sitemap index."""
    root = root_url if root_url.endswith("/") else root_url + "/"
    candidates = ["sitemap.xml", "sitemap_index.xml", "wp-sitemap.xml"]
    index_text = None
    for name in candidates:
        try:
            resp = requests.get(urljoin(root, name), timeout=timeout,
                                headers={"User-Agent": "InternalLinkAuditor/1.0"})
        except requests.RequestException:
            continue
        if resp.ok and ("<urlset" in resp.text or "<sitemapindex" in resp.text):
            index_text = resp.text
            break
    if index_text is None:
        return []

    locs = _locs(index_text)
    if "<sitemapindex" not in index_text:
        return _dedupe(locs)

    urls: list[str] = []
    for child in locs[:50]:
        try:
            resp = requests.get(child, timeout=timeout,
                                headers={"User-Agent": "InternalLinkAuditor/1.0"})
        except requests.RequestException:
            continue
        if resp.ok:
            urls.extend(_locs(resp.text))
    return _dedupe(urls)


def categorize(path: str) -> str:
    low = path.lower()
    if "/blog" in low:
        return "Blog"
    if any(h in low for h in POLICY_HINTS):
        return "Policy"
    if any(h in low for h in LANDING_HINTS):
        return "Landing/utility"
    return "Page"


# ---------------------------------------------------------------------------
# Tab builders
# ---------------------------------------------------------------------------

def build_summary(graph: dict, sitemap_only: list[str], sa_email: str | None) -> list[list]:
    pages = graph["pages"]
    links = graph["links"]
    excluded = graph.get("excluded", {})
    orphans = graph.get("orphans", [])
    max_depth = max((p.get("depth", 0) for p in pages.values()), default=0)
    non_asset = {u: p for u, p in pages.items() if "/wp-content/" not in u
                 and not u.lower().endswith((".mp4", ".pdf", ".jpg", ".png", ".webp"))}
    dead_ends = [u for u, p in non_asset.items()
                 if p.get("content_outbound", 0) == 0 and not p.get("is_start")]
    redirects = [u for u, p in pages.items()
                 if p.get("final_url") and p["final_url"] != u]
    generic = sum(1 for l in links if (l.get("anchor") or "").strip().lower() in GENERIC_ANCHORS)
    no_rel = all(not (l.get("rel") or []) for l in links)
    domain = graph.get("domain", "")

    rows: list[list] = [
        [f"{domain} — Internal Linking Audit", ""],
        ["Domain", domain],
        ["Canonical root", graph.get("canonical_root", "")],
        ["Crawled at (UTC)", graph.get("crawled_at", "")],
        ["Pages crawled", len(pages)],
        ["Pages failed", len(graph.get("failed", []))],
        ["Max crawl depth reached", max_depth],
        ["", ""],
        ["LINK METRICS", ""],
        ["Content-body links tracked", len(links)],
        ["Nav-container links excluded", excluded.get("nav_container_links", 0)],
        ["Repeating-boilerplate links excluded", excluded.get("repeating_boilerplate_links", 0)],
        ["LLM-adjudicated links excluded", excluded.get("llm_excluded_links", 0)],
        ["External links excluded", excluded.get("external_links", 0)],
        ["Out-of-scope links excluded", excluded.get("out_of_scope_links", 0)],
        ["Repeating blocks detected", graph.get("repeating_block_count", 0)],
        ["Blocks adjudicated (LLM)", graph.get("llm_decisions_applied", 0)],
        ["", ""],
        ["ISSUE COUNTS", ""],
        ["Orphan pages (content_inbound = 0)", len(orphans)],
        ["Content pages with zero content outbound (dead ends)", len(dead_ends)],
        ["Pages receiving >1 content inbound link", sum(
            1 for p in pages.values() if p.get("content_inbound", 0) > 1)],
        ["URLs that redirect to another canonical URL", len(redirects)],
        ["Sitemap URLs never reached by internal links", len(sitemap_only)],
        ["Generic content anchors", generic],
        ["", ""],
        ["PRIORITIZED RECOMMENDATIONS", ""],
    ]

    recs: list[str] = []
    if orphans:
        shown = ", ".join(orphans[:5]) + ("…" if len(orphans) > 5 else "")
        recs.append(f"Add internal links to {len(orphans)} orphan page(s): {shown}")
    if sitemap_only:
        recs.append(
            f"{len(sitemap_only)} indexable sitemap URL(s) get zero internal links "
            "(crawl-orphaned); link them from nav/footer or relevant hubs")
    if dead_ends:
        recs.append(
            f"Cross-link the {len(dead_ends)} dead-end page(s) (content_outbound = 0); "
            "each should link to 2-3 relevant siblings")
    if generic:
        recs.append(f"Replace {generic} generic anchor(s) (e.g. 'Learn More') with descriptive text")
    if redirects:
        recs.append(
            f"Point internal links directly at the canonical URL for {len(redirects)} "
            "redirecting URL(s) to stop splitting link equity")
    if no_rel and excluded.get("external_links"):
        recs.append(
            f"No rel=nofollow/sponsored/ugc found; review {excluded['external_links']} external link(s)")
    if not recs:
        recs.append("No structural issues detected.")
    rows.extend([[str(i + 1), r] for i, r in enumerate(recs)])
    return rows


def build_pages(graph: dict) -> list[list]:
    rows = [["URL", "Depth", "Status", "Title", "Content Outbound", "Content Inbound",
             "Nav Inbound", "PageRank", "Is Orphan", "Is Start"]]
    for u, p in sorted(graph["pages"].items(), key=lambda kv: (-kv[1].get("pagerank", 0), kv[0])):
        rows.append([u, p.get("depth"), p.get("status_code"), p.get("title"),
                     p.get("content_outbound"), p.get("content_inbound"),
                     p.get("nav_inbound"), p.get("pagerank"),
                     str(p.get("is_orphan")).lower(), str(p.get("is_start")).lower()])
    return rows


def build_orphans(graph: dict) -> list[list]:
    rows = [["URL", "Content Inbound", "Nav Inbound", "Type", "Notes"]]
    pages = graph["pages"]
    for u in graph.get("orphans", []):
        p = pages.get(u, {})
        nav = p.get("nav_inbound", 0)
        if nav > 0:
            typ = "nav-reachable, content-orphaned"
            note = "Reachable via navigation only; no in-body links"
        else:
            typ = "fully orphaned"
            note = "No internal links and not in navigation"
        if p.get("final_url") and p["final_url"] != u:
            note = f"Redirects to {p['final_url']}"
        rows.append([u, p.get("content_inbound", 0), nav, typ, note])
    return rows


def _is_page_url(url: str) -> bool:
    return not urlsplit(url).path.lower().endswith(ASSET_EXT)


def _strip_scheme(url: str) -> str:
    return re.sub(r"^https?://", "", url or "")


def _context(a, max_words: int = 15) -> tuple[str, int | None, int | None]:
    """Anchor text plus up to `max_words` of surrounding words.

    Returns (text, anchor_start, anchor_end) where the indices locate the anchor
    within `text` so it can be formatted separately. Climbs from the anchor to
    the nearest ancestor that holds at least `max_words` words, so a terse link
    label still gets the sentence around it.
    """
    anchor = re.sub(r"\s+", " ", a.get_text(" ", strip=True)).strip()
    container = None
    node = a
    for _ in range(8):
        node = node.parent
        if node is None:
            break
        text = re.sub(r"\s+", " ", node.get_text(" ", strip=True)).strip()
        if len(text.split()) >= max_words:
            container = text
            break
    if container is None:
        container = anchor
    if anchor and anchor in container:
        i = container.index(anchor)
        before, after = container[:i].split(), container[i + len(anchor):].split()
    else:
        before, after = [], container.split()
    aw = anchor.split()
    joined = " ".join(aw)
    budget = max(0, max_words - len(aw))
    left = before[-budget:] if budget else []
    right = after[:budget - len(left)]
    truncated_left = len(before) > len(left)
    truncated_right = len(after) > len(right)
    prefix = "..." if truncated_left else ""
    out = prefix + " ".join(left + aw + right) + ("..." if truncated_right else "")

    start = end = None
    if joined:
        start = len(prefix) + (len(" ".join(left)) + 1 if left else 0)
        end = start + len(joined)
        if out[start:end] != joined:  # defensive: fall back to a search
            idx = out.find(joined)
            start, end = (idx, idx + len(joined)) if idx != -1 else (None, None)
    return out, start, end


def _load_anchor_context(html_file: str | None, base_url: str) -> dict[str, list[tuple]]:
    """Map absolute href -> list of (parent_class, text, anchor_start, anchor_end)."""
    if not html_file:
        return {}
    try:
        html = Path(html_file).read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return {}
    try:
        soup = BeautifulSoup(html, "lxml")
    except Exception:
        soup = BeautifulSoup(html, "html.parser")
    out: dict[str, list[tuple]] = defaultdict(list)
    for a in soup.find_all("a", href=True):
        if a.find_parent(["nav", "header", "footer"]):
            continue
        href = a["href"].strip()
        if href.startswith(("mailto:", "tel:", "javascript:", "#")):
            continue
        parent = a.parent
        pclass = " ".join(parent.get("class", [])) if parent is not None else ""
        out[urljoin(base_url, href)].append((pclass, *_context(a)))
    return out


def _pick_context(contexts: dict[str, list[tuple]], target: str,
                  anchor: str, parent_class: str | None) -> tuple[str, int | None, int | None]:
    candidates: list[tuple] = []
    for key in (target, target.rstrip("/"), target.rstrip("/") + "/"):
        if key in contexts:
            candidates = contexts[key]
            break
    if not candidates:
        return anchor, None, None
    pclass = (parent_class or "").strip()
    if pclass:
        for pc, ctx, s, e in candidates:
            if pc == pclass and (not anchor or anchor in ctx):
                return ctx, s, e
    if anchor:
        for _pc, ctx, s, e in candidates:
            if anchor in ctx:
                return ctx, s, e
    c = candidates[0]
    return c[1], c[2], c[3]


def build_page_detail(graph: dict) -> tuple[list[list], list[tuple[int, int, int, int]]]:
    """Ideal page-detail view: one row per outbound page link, grouped by page.

    Columns: Page From | Page To | Anchor (+surrounding text) | Return links count.
    Page From is written once per group (blank on continuation rows); the last
    column lists, once per group, the pages that link TO this Page From.
    Non-page assets (e.g. .mp4) are excluded. Every crawled HTML page appears,
    even those with no outbound links.

    Returns (rows, spans) where each span is (row_index, col_index, start, end)
    marking the anchor inside the surrounding-text cell (col 2).
    """
    pages = graph["pages"]
    out_by_source: dict[str, list] = defaultdict(list)
    in_by_target: dict[str, list] = defaultdict(list)
    for l in graph["links"]:
        src, tgt = l.get("source", ""), l.get("target", "")
        if not (_is_page_url(src) and _is_page_url(tgt)):
            continue
        out_by_source[src].append(l)
        in_by_target[tgt].append(l)

    rows = [["Page From", "Page To", "Anchor (+surrounding text)", "Return links count"]]
    spans: list[tuple[int, int, int, int]] = []
    ordered = sorted(pages.items(), key=lambda kv: (-kv[1].get("pagerank", 0), kv[0]))
    for url, page in ordered:
        if not _is_page_url(url):
            continue
        returns = sorted({l.get("source", "") for l in in_by_target.get(url, [])
                          if l.get("source") and l.get("source") != url
                          and _is_page_url(l.get("source", ""))})
        returns_str = ", ".join(_strip_scheme(u) for u in returns)
        out = sorted(out_by_source.get(url, []), key=lambda l: l.get("target", ""))
        if not out:
            rows.append([_strip_scheme(url), "", "", returns_str])
            continue
        contexts = _load_anchor_context(page.get("html_file"), url)
        for i, l in enumerate(out):
            tgt = l.get("target", "")
            anchor = l.get("anchor", "") or ""
            ctx, start, end = _pick_context(contexts, tgt, anchor, l.get("parent_class"))
            rows.append([
                _strip_scheme(url) if i == 0 else "",
                _strip_scheme(tgt),
                ctx,
                returns_str if i == 0 else "",
            ])
            if start is not None and end is not None and end > start:
                spans.append((len(rows) - 1, 2, start, end))
    return rows, spans


def build_sitemap_coverage(graph: dict, sitemap_urls: list[str]) -> tuple[list[list], list[str]]:
    pages = graph["pages"]
    crawled_exact = set(pages)
    crawled_norm = {u.rstrip("/") for u in pages}
    root = graph.get("canonical_root", "").rstrip("/")
    rows = [["URL", "Crawled", "Content Inbound", "Category", "Notes"]]
    sitemap_only: list[str] = []
    for url in sitemap_urls:
        if root and not url.startswith(root):
            continue
        path = urlsplit(url).path or "/"
        is_crawled = url in crawled_exact or url.rstrip("/") in crawled_norm
        inbound = pages.get(url, {}).get("content_inbound", 0)
        cat = categorize(path)
        if is_crawled:
            note = "Discovered via crawl"
        else:
            sitemap_only.append(url)
            note = "Crawl-orphaned: indexable but no internal links point here"
        rows.append([url, "yes" if is_crawled else "no",
                     inbound if is_crawled else "0 (not crawled)", cat, note])
    return rows, sitemap_only


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def ensure_tabs(client: SheetsClient, titles: list[str]) -> dict[str, int]:
    meta = client.meta()
    existing = {s["properties"]["title"]: s["properties"]["sheetId"] for s in meta["sheets"]}
    reqs = []
    if "Sheet1" in existing and "Summary" not in existing and "Summary" in titles:
        reqs.append({"updateSheetProperties": {
            "properties": {"sheetId": existing["Sheet1"], "title": "Summary"},
            "fields": "title"}})
        existing["Summary"] = existing.pop("Sheet1")
    for t in titles:
        if t not in existing:
            reqs.append({"addSheet": {"properties": {"title": t}}})
    if reqs:
        client.batch_update(reqs)
        meta = client.meta()
        existing = {s["properties"]["title"]: s["properties"]["sheetId"] for s in meta["sheets"]}
    return existing


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Export an internal-linking crawl to Google Sheets.")
    p.add_argument("--spreadsheet-id", required=True, help="Target Google Sheet id.")
    p.add_argument("--check-access", action="store_true",
                   help="Only verify the sheet is shared with the service account "
                        "as Editor, print the result, and exit.")
    src = p.add_mutually_exclusive_group(required=False)
    src.add_argument("--crawl-dir", help="Directory containing link_graph.json.")
    src.add_argument("--url", help="Crawl start URL; derives the crawl dir.")
    p.add_argument("--output-dir", default="crawls", help="Base crawl dir for --url (default: crawls).")
    p.add_argument("--service-account", default=str(DEFAULT_SA), help="Service-account JSON path.")
    p.add_argument("--sitemap-url", help="Override sitemap URL (default: discover from canonical root).")
    p.add_argument("--no-sitemap", action="store_true", help="Skip sitemap coverage.")
    p.add_argument("--tabs", default=",".join(ALL_TABS),
                   help="Comma-separated subset of tabs to write.")
    p.add_argument("--remove-tabs", default="",
                   help="Comma-separated tab titles to delete from the sheet.")
    return p.parse_args(argv)


def check_access(args: argparse.Namespace) -> int:
    """Preflight: confirm the sheet exists and the service account can edit it."""
    sa_path = Path(args.service_account)
    sa_email = service_account_email(sa_path)
    base = {
        "spreadsheet_id": args.spreadsheet_id,
        "spreadsheet_url": f"https://docs.google.com/spreadsheets/d/{args.spreadsheet_id}/edit",
        "service_account_email": sa_email,
    }
    try:
        token = get_access_token(sa_path)
        client = SheetsClient(args.spreadsheet_id, token)
        client.sa_email = sa_email
        meta = client.meta()
    except UserError as exc:
        json.dump({**base, "ok": False, "can_edit": False, "error": str(exc)},
                  sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 1

    title = (meta.get("properties") or {}).get("title", "")
    can_edit = bool((meta.get("capabilities") or {}).get("canEdit"))
    result = {**base, "ok": can_edit, "can_edit": can_edit, "title": title}
    if not can_edit:
        result["error"] = (
            f"The service account can reach '{title}' but has no edit rights. "
            f"Share the sheet with {sa_email} as Editor, then re-run --check-access."
        )
    json.dump(result, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0 if can_edit else 1


def main(argv=None) -> int:
    args = parse_args(argv)
    if args.check_access:
        return check_access(args)
    if not args.crawl_dir and not args.url:
        json.dump({"ok": False, "error": "One of --crawl-dir or --url is required "
                   "(unless --check-access)."}, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 1
    tabs = [t.strip() for t in args.tabs.split(",") if t.strip()]
    unknown = [t for t in tabs if t not in ALL_TABS]
    if unknown:
        json.dump({"ok": False, "error": f"Unknown tab(s): {unknown}. Valid: {ALL_TABS}"},
                  sys.stdout, indent=2)
        return 1

    crawl_dir = Path(args.crawl_dir).resolve() if args.crawl_dir else \
        derive_crawl_dir(args.url, Path(args.output_dir).resolve())
    graph_path = crawl_dir / "link_graph.json"
    if not graph_path.exists():
        json.dump({"ok": False, "error": f"link_graph.json not found at {graph_path}"},
                  sys.stdout, indent=2)
        return 1
    graph = json.loads(graph_path.read_text(encoding="utf-8"))

    sa_path = Path(args.service_account)
    sa_email = service_account_email(sa_path)

    try:
        token = get_access_token(sa_path)
        client = SheetsClient(args.spreadsheet_id, token)
        client.sa_email = sa_email
        sheet_ids = ensure_tabs(client, tabs)

        remove = [t.strip() for t in args.remove_tabs.split(",") if t.strip()]
        if remove:
            existing = {s["properties"]["title"]: s["properties"]["sheetId"]
                        for s in client.meta()["sheets"]}
            dels = [{"deleteSheet": {"sheetId": existing[t]}}
                    for t in remove if t in existing and t not in tabs]
            if dels:
                client.batch_update(dels)
                sheet_ids = {k: v for k, v in sheet_ids.items() if k not in remove}

        # Gather sitemap coverage first so Summary can cite sitemap-only count.
        sitemap_rows, sitemap_only = [], []
        if "Sitemap Coverage" in tabs and not args.no_sitemap:
            root = args.sitemap_url or graph.get("canonical_root", "")
            urls = fetch_sitemap_urls(root)
            sitemap_rows, sitemap_only = build_sitemap_coverage(graph, urls)

        builders = {
            "Summary": lambda: build_summary(graph, sitemap_only, sa_email),
            "Pages": lambda: build_pages(graph),
            "Orphans": lambda: build_orphans(graph),
            "Sitemap Coverage": lambda: sitemap_rows,
        }

        client.clear([f"'{t}'!A1:Z10000" for t in tabs])
        tab_values: dict[str, list[list]] = {}
        detail_spans: list[tuple[int, int, int, int]] = []
        for t in tabs:
            if t == "Page Detail":
                tab_values[t], detail_spans = build_page_detail(graph)
            else:
                tab_values[t] = builders[t]()
        data = [{"range": f"'{t}'!A1", "values": tab_values[t]} for t in tabs]
        client.write_values(data)

        fmt = []
        for t in tabs:
            sid = sheet_ids[t]
            fmt.append({"repeatCell": {
                "range": {"sheetId": sid, "startRowIndex": 0, "endRowIndex": 1},
                "cell": {"userEnteredFormat": {
                    "textFormat": {"bold": True},
                    "backgroundColor": {"red": 0.9, "green": 0.9, "blue": 0.9}}},
                "fields": "userEnteredFormat(textFormat,backgroundColor)"}})
            fmt.append({"updateSheetProperties": {
                "properties": {"sheetId": sid, "gridProperties": {"frozenRowCount": 1}},
                "fields": "gridProperties.frozenRowCount"}})

        # Red + bold just the anchor run inside each Page Detail context cell.
        if "Page Detail" in tabs and detail_spans:
            sid = sheet_ids["Page Detail"]
            for r, c, start, end in detail_spans:
                length = len(tab_values["Page Detail"][r][c])
                runs = [{"startIndex": start, "format": {
                    "bold": True,
                    "foregroundColor": {"red": 0.8, "green": 0.0, "blue": 0.0}}}]
                if end < length:  # reset run must be a valid (in-range) index
                    runs.append({"startIndex": end, "format": {}})
                fmt.append({"updateCells": {
                    "range": {"sheetId": sid, "startRowIndex": r, "endRowIndex": r + 1,
                              "startColumnIndex": c, "endColumnIndex": c + 1},
                    "rows": [{"values": [{"textFormatRuns": runs}]}],
                    "fields": "textFormatRuns"}})
        client.batch_update(fmt)

        result = {
            "ok": True,
            "spreadsheet_id": args.spreadsheet_id,
            "spreadsheet_url": f"https://docs.google.com/spreadsheets/d/{args.spreadsheet_id}/edit",
            "crawl_dir": str(crawl_dir),
            "tabs": tabs,
            "rows": {t: len(tab_values[t]) for t in tabs},
            "sitemap_urls": len(sitemap_rows) - 1 if sitemap_rows else 0,
            "sitemap_only": len(sitemap_only),
        }
        json.dump(result, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 0
    except UserError as exc:
        json.dump({"ok": False, "error": str(exc), "service_account_email": sa_email},
                  sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 1
    except Exception as exc:  # noqa: BLE001
        json.dump({"ok": False, "error": str(exc)}, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
