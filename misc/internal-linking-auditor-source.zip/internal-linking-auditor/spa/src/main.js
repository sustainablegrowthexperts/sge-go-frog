import "./styles.css";
import { analyzeCrawl } from "./lib/analyze.js";
import { crawlSite } from "./lib/crawl.js";
import {
  anchorsCsv,
  auditJson,
  blocksCsv,
  decisionsJson,
  downloadText,
  linksCsv,
  orphansCsv,
  pagesCsv,
} from "./lib/export.js";
import { classifyBlocks } from "./lib/llm.js";
import { hasScheme, normalizeUrl, shortUrl } from "./lib/url.js";

const EXCLUDED_EFFECTIVE = new Set([
  "nav",
  "navigation",
  "menu",
  "header",
  "footer",
  "boilerplate",
  "exclude",
  "template",
  "chrome",
]);

const EXPORT_BUTTONS = [
  "export-json",
  "export-pages",
  "export-links",
  "export-orphans",
  "export-anchors",
  "export-blocks",
  "export-decisions",
];

const state = {
  busy: false,
  stopped: false,
  abort: null,
  crawl: null,
  analysis: null,
  blocks: [],
  decisions: new Map(),
  options: null,
  logs: [],
  activeTab: "overview",
  blockFilter: "review",
  blockQuery: "",
  pageQuery: "",
  linkQuery: "",
};

const numberFormatter = new Intl.NumberFormat();

function $(id) {
  return document.getElementById(id);
}

function h(tag, attrs = {}, ...children) {
  const element = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value === undefined || value === null || value === false) continue;
    if (key === "class") element.className = value;
    else if (key === "text") element.textContent = value;
    else if (key === "dataset") Object.assign(element.dataset, value);
    else if (key.startsWith("on") && typeof value === "function") {
      element.addEventListener(key.slice(2).toLowerCase(), value);
    } else {
      element.setAttribute(key, value === true ? "" : String(value));
    }
  }
  appendChildren(element, children);
  return element;
}

function appendChildren(element, children) {
  for (const child of children.flat(Infinity)) {
    if (child === null || child === undefined || child === false) continue;
    element.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
}

function td(content, attrs = {}) {
  const cell = h("td", attrs);
  appendChildren(cell, [content]);
  return cell;
}

function badge(text, tone = "neutral") {
  return h("span", { class: `badge badge-${tone}`, text: String(text) });
}

function labelBadge(label) {
  const tones = { content: "ok", nav: "danger", boilerplate: "warn" };
  return badge(label, tones[label] || "neutral");
}

function anchorFor(url, text = shortUrl(url)) {
  return h("a", {
    href: url,
    target: "_blank",
    rel: "noopener noreferrer",
    text,
  });
}

function formatNumber(value) {
  return numberFormatter.format(Number(value) || 0);
}

function table(headers, rows) {
  return h(
    "div",
    { class: "table-wrap" },
    h(
      "table",
      { class: "data-table" },
      h("thead", {}, h("tr", {}, ...headers.map((header) => h("th", { text: header })))),
      h("tbody", {}, ...rows),
    ),
  );
}

function panel(title, subtitle, ...children) {
  return h(
    "section",
    { class: "panel" },
    h(
      "div",
      { class: "panel-head" },
      h(
        "div",
        {},
        h("h2", { text: title }),
        subtitle ? h("p", { class: "muted", text: subtitle }) : null,
      ),
    ),
    ...children,
  );
}

function tablePanel(title, subtitle, headers, rows) {
  const section = panel(title, subtitle);
  if (!rows.length) section.append(h("p", { class: "empty", text: "Nothing to show." }));
  else section.append(table(headers, rows));
  return section;
}

function notice(text, tone = "info") {
  return h("div", { class: `notice notice-${tone}`, text });
}

function stat(label, value, note) {
  return h(
    "div",
    { class: "stat" },
    h("div", { class: "stat-label", text: label }),
    h("div", { class: "stat-value", text: String(value) }),
    h("div", { class: "stat-note", text: note || "" }),
  );
}

function setStatus(element, message, tone = "info") {
  element.textContent = message;
  element.dataset.tone = tone;
}

function setFormError(message) {
  const box = $("form-error");
  box.textContent = message || "";
  box.hidden = !message;
}

function addLog(message) {
  state.logs.push(message);
  if (state.logs.length > 300) state.logs.shift();
  const log = $("log");
  log.textContent = state.logs.join("\n");
  log.scrollTop = log.scrollHeight;
}

function clampInt(value, min, max, fallback) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

function setTab(name) {
  state.activeTab = name;
  for (const button of document.querySelectorAll(".tab")) {
    const active = button.dataset.tab === name;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-selected", active ? "true" : "false");
  }
  for (const view of document.querySelectorAll(".view")) {
    view.hidden = view.dataset.view !== name;
  }
}

function setBusyUi(busy) {
  $("crawl-btn").disabled = busy;
  $("stop-btn").hidden = !busy;
  for (const id of ["url", "depth", "max-pages", "delay", "timeout", "proxy"]) {
    $(id).disabled = busy;
  }
  if (!busy) syncProxyInputs();
  else $("custom-proxy").disabled = true;
}

function syncProxyInputs() {
  const isCustom = $("proxy").value === "custom";
  $("custom-proxy").disabled = !isCustom || state.busy;
}

function updateProgress({ crawled, queued, depth, current }) {
  $("status-text").textContent = current
    ? `Fetching depth ${depth}: ${shortUrl(current, 76)}`
    : "Crawling…";
  $("progress-count").textContent = `${formatNumber(crawled)} pages · ${formatNumber(queued)} queued`;
  const max = state.options?.maxPages || 1;
  $("bar-fill").style.width = `${Math.min(100, (crawled / max) * 100)}%`;
}

function baseName() {
  const domain = state.analysis?.domain || "audit";
  return `internal-links-${domain.replace(/[^a-z0-9.-]+/gi, "-")}`;
}

function filteredBlocks() {
  const query = state.blockQuery.trim().toLowerCase();
  return state.blocks.filter((block) => {
    if (!blockMatchesFilter(block)) return false;
    if (!query) return true;
    return [
      block.tag,
      block.id,
      block.class,
      block.block_id,
      block.effective_label,
      ...(block.anchors || []),
      block.snippet,
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase()
      .includes(query);
  });
}

function blockMatchesFilter(block) {
  switch (state.blockFilter) {
    case "review":
      return block.needs_review;
    case "auto":
      return Boolean(block.auto_excluded);
    case "overridden":
      return Boolean(block.decision);
    case "content":
      return block.effective_label === "content";
    case "excluded":
      return EXCLUDED_EFFECTIVE.has(block.effective_label);
    default:
      return true;
  }
}

function blockRow(block) {
  const name = [
    block.tag,
    block.id ? `#${block.id}` : "",
    block.class ? `.${block.class.split(/\s+/).join(".")}` : "",
  ].join("");
  const scoreTone =
    block.nav_score >= 0.6 ? "danger" : block.nav_score >= 0.4 ? "warn" : "neutral";

  const select = h("select", {
    class: "select-small",
    "data-block-id": block.block_id,
  });
  for (const [value, label] of [
    ["auto", `Auto (${block.auto_label})`],
    ["content", "Content"],
    ["nav", "Nav"],
    ["boilerplate", "Boilerplate"],
  ]) {
    select.append(h("option", { value, text: label }));
  }
  select.value = block.decision || "auto";

  const effectiveCell = td(labelBadge(block.effective_label), {
    class: "effective-cell",
  });

  return h(
    "tr",
    {},
    td(badge(block.nav_score.toFixed(2), scoreTone)),
    td(
      h("div", { class: "block-cell" }, h("code", { text: name })),
      h(
        "div",
        { class: "muted small" },
        `${block.link_count} links · ${block.page_count} pages · ${Math.round(
          block.link_text_ratio * 100,
        )}% link text`,
      ),
      h(
        "details",
        { class: "snippet-details" },
        h("summary", { text: "Snippet & anchors" }),
        block.anchors?.length
          ? h("div", { class: "muted small", text: `Anchors: ${block.anchors.join(" · ")}` })
          : null,
        h("pre", { class: "snippet", text: block.snippet }),
      ),
    ),
    td(block.link_count),
    td(`${Math.round(block.link_text_ratio * 100)}%`),
    td(block.position),
    td(block.page_count, {
      title: block.sample_pages.join("\n"),
    }),
    td(block.auto_excluded ? badge(block.auto_excluded, "neutral") : "—"),
    td(select),
    effectiveCell,
  );
}

function renderBlocks() {
  const container = $("blocks-table");
  const items = filteredBlocks();
  container.replaceChildren();

  if (!items.length) {
    container.append(h("p", { class: "empty", text: "No blocks match this filter." }));
    $("block-count").textContent = "";
    return;
  }

  const visible = items.slice(0, 300);
  container.append(
    table(
      ["Score", "Block", "Links", "Ratio", "Position", "Pages", "Auto", "Decision", "Effective"],
      visible.map(blockRow),
    ),
  );
  $("block-count").textContent =
    items.length > visible.length
      ? `Showing ${visible.length} of ${items.length} blocks. Export the CSV for the full list.`
      : `${items.length} blocks.`;
}

function renderBlockSummary() {
  if (!state.analysis) {
    $("block-summary").textContent = "";
    return;
  }
  const structure = state.analysis.structure;
  $("block-summary").textContent =
    `${formatNumber(structure.total_blocks)} blocks detected · ` +
    `${formatNumber(structure.blocks_needing_review)} flagged · ` +
    `${formatNumber(state.decisions.size)} overrides · ` +
    `${formatNumber(structure.auto_excluded_blocks)} auto-boilerplate`;
}

function renderOverview() {
  const analysis = state.analysis;
  const root = $("overview-content");
  root.replaceChildren();

  root.append(
    h(
      "div",
      { class: "cards" },
      stat("Pages", formatNumber(analysis.pages.size), `${formatNumber(analysis.failed.length)} failed`),
      stat(
        "Content links",
        formatNumber(analysis.links.length),
        `${formatNumber(analysis.raw_link_count)} in-scope extracted`,
      ),
      stat("Orphans", formatNumber(analysis.orphans.length), "zero content inbound"),
      stat(
        "Blocks",
        formatNumber(analysis.structure.total_blocks),
        `${formatNumber(analysis.structure.blocks_reviewed)} overrides`,
      ),
      stat(
        "Top PageRank share",
        `${(analysis.top_share * 100).toFixed(1)}%`,
        analysis.ranking[0] ? shortUrl(analysis.ranking[0].url, 28) : "—",
      ),
    ),
  );

  if (analysis.cancelled) {
    root.append(
      notice(
        "This audit was stopped early. Results cover only the pages fetched before the stop.",
        "warn",
      ),
    );
  }
  if (analysis.top_share > 0.35) {
    root.append(
      notice(
        `Concentration risk: the top page holds ${(analysis.top_share * 100).toFixed(
          1,
        )}% of crawled PageRank.`,
        "warn",
      ),
    );
  }

  root.append(renderOrphans(analysis));

  const total = analysis.ranking.length;
  const top = analysis.ranking.slice(0, 5);
  const bottom = total > 5 ? analysis.ranking.slice(-5).reverse() : [];
  root.append(
    panel(
      "Internal PageRank",
      "Highest and lowest link-juice recipients across crawled pages.",
      h(
        "div",
        { class: "split" },
        rankTable("Most linked-to", top),
        bottom.length
          ? rankTable("Least linked-to", bottom)
          : h("p", { class: "empty", text: "Not enough pages for a lowest-five view." }),
      ),
    ),
  );

  root.append(renderStructure(analysis));

  if (analysis.failed.length) {
    root.append(
      panel(
        "Failed fetches",
        `${analysis.failed.length} URL(s) could not be fetched; the audit continues with the rest.`,
        h(
          "details",
          {},
          h("summary", { text: "Show failures" }),
          h(
            "ul",
            { class: "failure-list" },
            ...analysis.failed.slice(0, 100).map((failure) =>
              h(
                "li",
                {},
                h("code", { text: shortUrl(failure.url, 80) }),
                h("span", { class: "muted", text: ` — ${failure.error}` }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

function renderOrphans(analysis) {
  const section = panel(
    "Orphaned pages",
    "Pages with zero content-body inbound links; the start URL is excluded by definition.",
  );
  if (!analysis.orphans.length) {
    section.append(h("p", { class: "empty", text: "No orphaned pages found." }));
    return section;
  }
  const rows = analysis.orphans.map((url) => {
    const page = analysis.pages.get(url);
    return h(
      "tr",
      {},
      td(anchorFor(url)),
      td(page?.title || "—"),
      td(page?.depth ?? "—"),
      td(
        page?.nav_inbound
          ? badge(`nav-reachable (${page.nav_inbound})`, "warn")
          : badge("unreachable", "danger"),
      ),
      td((page?.pagerank ?? 0).toFixed(6)),
    );
  });
  section.append(table(["Page", "Title", "Depth", "Status", "PageRank"], rows));
  return section;
}

function rankTable(title, entries) {
  const rows = entries.map(
    (entry) =>
      h(
        "tr",
        {},
        td(anchorFor(entry.url)),
        td(entry.pagerank.toFixed(6)),
        td(entry.content_inbound),
      ),
  );
  return h(
    "div",
    { class: "rank-block" },
    h("h3", { text: title }),
    table(["Page", "PageRank", "Content in"], rows),
  );
}

function renderStructure(analysis) {
  const excludedRows = [
    ["Nav container links", analysis.excluded.nav_container_links],
    ["Repeating boilerplate links", analysis.excluded.repeating_boilerplate_links],
    ["Block-excluded links", analysis.excluded.block_excluded_links],
    ["External links", analysis.excluded.external_links],
    ["Out-of-scope links", analysis.excluded.out_of_scope_links],
    ["Non-http links", analysis.excluded.non_http_links],
  ].map(([label, count]) => h("tr", {}, td(label), td(formatNumber(count))));

  const parentRows = analysis.structure.by_parent_tag.map((entry) =>
    h("tr", {}, td(entry.parent_tag), td(formatNumber(entry.count))),
  );

  return panel(
    "Structural breakdown",
    `Canonical root enforced: ${analysis.canonical_root}`,
    h(
      "div",
      { class: "split" },
      h(
        "div",
        { class: "rank-block" },
        h("h3", { text: "Content links by parent tag" }),
        parentRows.length
          ? table(["Parent tag", "Links"], parentRows)
          : h("p", { class: "empty", text: "No content links." }),
      ),
      h(
        "div",
        { class: "rank-block" },
        h("h3", { text: "Filtered out" }),
        table(["Reason", "Links"], excludedRows),
        h(
          "p",
          { class: "muted small" },
          `${formatNumber(analysis.structure.repeating_block_count)} repeating block signatures detected; ` +
            `${formatNumber(analysis.structure.decisions_applied)} decisions applied.`,
        ),
      ),
    ),
  );
}

function renderPages() {
  const analysis = state.analysis;
  const query = state.pageQuery.trim().toLowerCase();
  const pages = [...analysis.pages.values()]
    .sort((a, b) => a.url.localeCompare(b.url))
    .filter(
      (page) =>
        !query ||
        `${page.url} ${page.title || ""}`.toLowerCase().includes(query),
    );

  $("pages-summary").textContent = `${formatNumber(analysis.pages.size)} pages crawled · ${formatNumber(
    analysis.failed.length,
  )} failed`;
  const container = $("pages-table");
  container.replaceChildren();

  if (!pages.length) {
    container.append(h("p", { class: "empty", text: "No pages match this filter." }));
    return;
  }

  const visible = pages.slice(0, 1000);
  const rows = visible.map((page) =>
    h(
      "tr",
      {},
      td(anchorFor(page.url)),
      td(page.title || "—"),
      td(page.depth),
      td(page.content_inbound),
      td(page.content_outbound),
      td(page.nav_inbound),
      td(page.pagerank.toFixed(6)),
      td(page.is_orphan ? badge("orphan", "danger") : badge("linked", "ok")),
    ),
  );
  container.append(
    table(
      ["Page", "Title", "Depth", "In", "Out", "Nav in", "PageRank", "State"],
      rows,
    ),
  );
  if (pages.length > visible.length) {
    container.append(
      h("p", {
        class: "muted small",
        text: `Showing ${visible.length} of ${pages.length} pages. Export the CSV for the full list.`,
      }),
    );
  }
}

function renderLinks() {
  const analysis = state.analysis;
  const query = state.linkQuery.trim().toLowerCase();
  const links = analysis.links.filter(
    (link) =>
      !query ||
      `${link.source} ${link.target} ${link.anchor} ${link.parent_tag || ""} ${
        link.parent_class || ""
      }`
        .toLowerCase()
        .includes(query),
  );

  $("links-summary").textContent = `${formatNumber(analysis.links.length)} content-body links · ${formatNumber(
    analysis.excluded.nav_container_links +
      analysis.excluded.repeating_boilerplate_links +
      analysis.excluded.block_excluded_links,
  )} filtered by block rules`;
  const container = $("links-table");
  container.replaceChildren();

  if (!links.length) {
    container.append(h("p", { class: "empty", text: "No links match this filter." }));
    return;
  }

  const visible = links.slice(0, 500);
  const rows = visible.map((link) => {
    const parent = [link.parent_tag, link.parent_id ? `#${link.parent_id}` : ""]
      .filter(Boolean)
      .join("");
    return h(
      "tr",
      {},
      td(anchorFor(link.source)),
      td(anchorFor(link.target)),
      td(link.anchor || "—"),
      td(parent || "—", { title: link.parent_class || "" }),
      td((link.rel || []).join(" ") || "—"),
      td(link.context || "—", { title: link.context || "" }),
    );
  });
  container.append(
    table(["Source", "Target", "Anchor", "Parent", "Rel", "Context"], rows),
  );
  if (links.length > visible.length) {
    container.append(
      h("p", {
        class: "muted small",
        text: `Showing ${visible.length} of ${links.length} links. Export the CSV for the full list.`,
      }),
    );
  }
}

function renderAnchors() {
  const root = $("anchors-content");
  root.replaceChildren();
  const anchors = state.analysis.anchors;

  root.append(
    tablePanel(
      "Top anchor texts",
      "Exact anchor text over content-body links.",
      ["Anchor", "Links", "Distinct targets"],
      anchors.top_anchors.map((entry) =>
        h("tr", {}, td(entry.anchor), td(entry.count), td(entry.distinct_targets)),
      ),
    ),
  );

  root.append(
    tablePanel(
      "Top anchor targets",
      "Pages receiving the most content links.",
      ["Target", "Links", "Distinct anchors"],
      anchors.top_targets.map((entry) =>
        h(
          "tr",
          {},
          td(anchorFor(entry.target)),
          td(entry.count),
          td(entry.distinct_anchors),
        ),
      ),
    ),
  );

  root.append(
    tablePanel(
      "Possible over-optimization",
      "The same exact-match anchor points at one target from 3+ distinct pages.",
      ["Anchor", "Target", "Sources", "Sample sources"],
      anchors.over_optimization.map((entry) =>
        h(
          "tr",
          {},
          td(entry.anchor),
          td(anchorFor(entry.target)),
          td(entry.source_count),
          td(entry.sources.join(", ")),
        ),
      ),
    ),
  );

  const genericRows = anchors.generic.map((entry) =>
    h("tr", {}, td(entry.anchor), td(entry.count)),
  );
  const relRows = anchors.rel_usage.map((entry) =>
    h("tr", {}, td(entry.rel), td(entry.count)),
  );
  const imageRows = anchors.image_or_empty.samples.map((entry) =>
    h(
      "tr",
      {},
      td(anchorFor(entry.source)),
      td(anchorFor(entry.target)),
      td(entry.anchor || "(empty)"),
    ),
  );

  root.append(
    h(
      "div",
      { class: "split" },
      tablePanel(
        "Generic anchors",
        "Low-signal anchor text.",
        ["Anchor", "Links"],
        genericRows,
      ),
      tablePanel(
        "rel usage",
        "nofollow / sponsored / ugc on content links.",
        ["Rel", "Links"],
        relRows,
      ),
    ),
  );

  root.append(
    tablePanel(
      "Image-only or empty anchors",
      `${formatNumber(anchors.image_or_empty.count)} content links have no text anchor.`,
      ["Source", "Target", "Anchor"],
      imageRows,
    ),
  );
}

function renderExport() {
  const hasAnalysis = Boolean(state.analysis);
  for (const id of EXPORT_BUTTONS) $(id).disabled = !hasAnalysis;
  $("decisions-preview").textContent = decisionsJson(state.decisions);
}

function recomputeAndRender({ renderBlockTable = true } = {}) {
  if (!state.crawl) return;
  state.analysis = analyzeCrawl(state.crawl, state.decisions);
  state.blocks = state.analysis.blocks;
  renderOverview();
  renderPages();
  renderLinks();
  renderAnchors();
  renderExport();
  renderBlockSummary();
  if (renderBlockTable) renderBlocks();
}

async function startCrawl(event) {
  event.preventDefault();
  if (state.busy) return;

  setFormError("");
  let rawUrl = $("url").value.trim();
  if (!rawUrl) {
    setFormError("Enter a start URL.");
    return;
  }
  if (!hasScheme(rawUrl)) rawUrl = `https://${rawUrl}`;

  let startUrl;
  try {
    startUrl = normalizeUrl(rawUrl);
  } catch {
    setFormError("That URL is not valid.");
    return;
  }

  const options = {
    url: startUrl,
    depth: clampInt($("depth").value, 0, 6, 3),
    maxPages: clampInt($("max-pages").value, 1, 1000, 200),
    delayMs: clampInt($("delay").value, 0, 5000, 120),
    timeoutMs: clampInt($("timeout").value, 5, 120, 20) * 1000,
    proxy: $("proxy").value,
    customProxy: $("custom-proxy").value.trim(),
  };

  if (options.proxy === "custom" && !options.customProxy) {
    setFormError("Enter a custom proxy URL.");
    return;
  }

  state.options = options;
  state.busy = true;
  state.stopped = false;
  state.decisions = new Map();
  state.crawl = null;
  state.analysis = null;
  state.blocks = [];
  state.logs = [];
  state.blockFilter = "review";
  state.blockQuery = "";
  state.pageQuery = "";
  state.linkQuery = "";
  $("block-filter").value = "review";
  $("block-search").value = "";
  $("page-search").value = "";
  $("link-search").value = "";
  $("results").hidden = true;
  $("progress").hidden = false;
  setFormError("");
  setBusyUi(true);
  renderExport();
  addLog(`Start ${startUrl} (depth ${options.depth}, max ${options.maxPages} pages, proxy ${options.proxy})`);
  updateProgress({ crawled: 0, queued: 1, depth: 0, current: startUrl });

  const controller = new AbortController();
  state.abort = () => controller.abort();

  try {
    const crawl = await crawlSite(
      {
        ...options,
        signal: controller.signal,
        shouldStop: () => state.stopped,
      },
      {
        onProgress: updateProgress,
        onPage: ({ url, depth, linkCount }) => {
          addLog(`✓ depth ${depth} ${shortUrl(url, 90)} · ${linkCount} links`);
        },
        onFailure: ({ url, error }) => {
          addLog(`✗ ${shortUrl(url, 90)} · ${error}`);
        },
      },
    );

    state.crawl = crawl;

    if (!crawl.pages.size) {
      $("status-text").textContent = "No pages crawled";
      addLog("No pages were crawled. Check the URL, proxy, and site availability.");
      setFormError("No pages could be fetched. Try another proxy or URL.");
      return;
    }

    addLog(
      crawl.cancelled
        ? `Stopped early. Analyzing ${crawl.pages.size} fetched pages.`
        : `Crawl complete: ${crawl.pages.size} pages, ${crawl.links.length} in-scope links, ${crawl.failed.length} failed.`,
    );
    recomputeAndRender({ renderBlockTable: true });
    $("results").hidden = false;
    $("status-text").textContent = crawl.cancelled
      ? "Stopped — partial audit ready"
      : "Audit ready";
    $("progress-count").textContent = `${formatNumber(crawl.pages.size)} pages · ${formatNumber(
      crawl.links.length,
    )} links · ${formatNumber(crawl.failed.length)} failed`;
    setTab("overview");
  } catch (error) {
    $("status-text").textContent = "Crawl failed";
    addLog(`Crawl failed: ${error?.message || error}`);
    setFormError(error?.message || String(error));
  } finally {
    state.busy = false;
    state.abort = null;
    setBusyUi(false);
  }
}

function onDecisionChange(event) {
  const select = event.target.closest("select[data-block-id]");
  if (!select) return;
  const block = state.blocks.find((entry) => entry.block_id === select.dataset.blockId);
  if (!block) return;

  const value = select.value;
  if (value === "auto") state.decisions.delete(block.block_id);
  else state.decisions.set(block.block_id, value);

  const effective = value === "auto" ? block.auto_label : value;
  const cell = select.closest("tr")?.querySelector(".effective-cell");
  if (cell) cell.replaceChildren(labelBadge(effective));

  recomputeAndRender({ renderBlockTable: false });
  if (state.blockFilter !== "all" || state.blockQuery) renderBlocks();
}

async function onClassify() {
  if (!state.analysis) return;

  const endpoint = $("llm-endpoint").value.trim();
  const model = $("llm-model").value.trim();
  const apiKey = $("llm-key").value.trim();

  if (!endpoint || !model) {
    setStatus($("ai-status"), "Endpoint and model are required.", "error");
    return;
  }
  if (!apiKey) {
    setStatus($("ai-status"), "Enter an API key (kept in sessionStorage).", "error");
    return;
  }

  sessionStorage.setItem("ila.llm-key", apiKey);
  localStorage.setItem("ila.llm-endpoint", endpoint);
  localStorage.setItem("ila.llm-model", model);

  const candidates = state.blocks
    .filter((block) => block.auto_excluded !== "repeated_block")
    .slice(0, 150);
  if (!candidates.length) {
    setStatus($("ai-status"), "No candidate blocks to classify.", "warn");
    return;
  }

  $("classify-btn").disabled = true;
  setStatus(
    $("ai-status"),
    `Sending ${candidates.length} blocks in one request…`,
    "info",
  );

  try {
    const decisions = await classifyBlocks(candidates, { endpoint, model, apiKey });
    let changed = 0;
    for (const [blockId, label] of Object.entries(decisions)) {
      const block = state.blocks.find((entry) => entry.block_id === blockId);
      if (!block) continue;
      if (label === block.auto_label) {
        state.decisions.delete(blockId);
      } else if (state.decisions.get(blockId) !== label) {
        state.decisions.set(blockId, label);
        changed += 1;
      }
    }
    recomputeAndRender({ renderBlockTable: true });
    setStatus(
      $("ai-status"),
      `Applied ${Object.keys(decisions).length} labels (${changed} overrides).`,
      "ok",
    );
  } catch (error) {
    setStatus($("ai-status"), error?.message || String(error), "error");
  } finally {
    $("classify-btn").disabled = false;
  }
}

async function onImportDecisions(event) {
  const file = event.target.files?.[0];
  if (!file || !state.blocks.length) return;

  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    const raw = parsed.decisions || parsed;
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      throw new Error("Expected a decisions object keyed by block id.");
    }

    const known = new Set(state.blocks.map((block) => block.block_id));
    const next = new Map();
    let skipped = 0;
    for (const [blockId, value] of Object.entries(raw)) {
      const label = String(value || "").trim().toLowerCase();
      if (!known.has(blockId) || !["content", "nav", "boilerplate"].includes(label)) {
        skipped += 1;
        continue;
      }
      next.set(blockId, label);
    }

    state.decisions = next;
    recomputeAndRender({ renderBlockTable: true });
    setStatus(
      $("import-status"),
      `Imported ${next.size} decisions${skipped ? `, skipped ${skipped}` : ""}.`,
      "ok",
    );
  } catch (error) {
    setStatus($("import-status"), error?.message || String(error), "error");
  } finally {
    event.target.value = "";
  }
}

function bindEvents() {
  $("crawl-form").addEventListener("submit", startCrawl);

  $("stop-btn").addEventListener("click", () => {
    state.stopped = true;
    state.abort?.();
    addLog("Stop requested…");
  });

  for (const button of document.querySelectorAll(".tab")) {
    button.addEventListener("click", () => setTab(button.dataset.tab));
  }

  $("proxy").addEventListener("change", syncProxyInputs);

  $("block-filter").addEventListener("change", (event) => {
    state.blockFilter = event.target.value;
    renderBlocks();
  });
  $("block-search").addEventListener("input", (event) => {
    state.blockQuery = event.target.value;
    renderBlocks();
  });
  $("blocks-table").addEventListener("change", onDecisionChange);

  $("reset-decisions").addEventListener("click", () => {
    state.decisions.clear();
    recomputeAndRender({ renderBlockTable: true });
  });

  $("classify-btn").addEventListener("click", onClassify);

  $("page-search").addEventListener("input", (event) => {
    state.pageQuery = event.target.value;
    renderPages();
  });
  $("link-search").addEventListener("input", (event) => {
    state.linkQuery = event.target.value;
    renderLinks();
  });

  $("export-json").addEventListener("click", () => {
    if (!state.analysis) return;
    downloadText(
      `${baseName()}.json`,
      auditJson(state.analysis, state.crawl, state.options),
      "application/json",
    );
  });
  $("export-pages").addEventListener("click", () => {
    if (state.analysis) downloadText(`${baseName()}-pages.csv`, pagesCsv(state.analysis), "text/csv;charset=utf-8");
  });
  $("export-links").addEventListener("click", () => {
    if (state.analysis) downloadText(`${baseName()}-links.csv`, linksCsv(state.analysis), "text/csv;charset=utf-8");
  });
  $("export-orphans").addEventListener("click", () => {
    if (state.analysis) downloadText(`${baseName()}-orphans.csv`, orphansCsv(state.analysis), "text/csv;charset=utf-8");
  });
  $("export-anchors").addEventListener("click", () => {
    if (state.analysis) downloadText(`${baseName()}-anchors.csv`, anchorsCsv(state.analysis), "text/csv;charset=utf-8");
  });
  $("export-blocks").addEventListener("click", () => {
    if (state.analysis) downloadText(`${baseName()}-blocks.csv`, blocksCsv(state.analysis), "text/csv;charset=utf-8");
  });
  $("export-decisions").addEventListener("click", () => {
    downloadText(
      `${baseName()}-block-decisions.json`,
      decisionsJson(state.decisions),
      "application/json",
    );
  });

  $("import-decisions").addEventListener("change", onImportDecisions);
}

function applyConfigDefaults() {
  const env = import.meta.env || {};
  const proxy = env.VITE_DEFAULT_PROXY || "allorigins";
  if ([...$("proxy").options].some((option) => option.value === proxy)) {
    $("proxy").value = proxy;
  }
  $("custom-proxy").value = env.VITE_CORS_PROXY || "";
  $("llm-endpoint").value =
    localStorage.getItem("ila.llm-endpoint") ||
    env.VITE_LLM_ENDPOINT ||
    "https://api.openai.com/v1/chat/completions";
  $("llm-model").value =
    localStorage.getItem("ila.llm-model") ||
    env.VITE_LLM_MODEL ||
    "gpt-4o-mini";
  $("llm-key").value = sessionStorage.getItem("ila.llm-key") || "";
  syncProxyInputs();
}

function init() {
  applyConfigDefaults();
  bindEvents();
  setTab("overview");
  renderExport();
}

init();
