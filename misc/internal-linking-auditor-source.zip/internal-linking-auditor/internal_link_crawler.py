#!/usr/bin/env python3
"""Internal link crawler with canonical locking and LLM-assisted nav exclusion.

Phase 1 - crawl:
    ./.venv/bin/python3 internal_link_crawler.py --url https://example.com --depth 3

    Fetches pages under the canonical root, applies deterministic navigation
    exclusion (header/nav/footer markers + repeating boilerplate blocks), saves
    raw HTML, and writes two artifacts:

        crawls/<domain-hash>/crawl_raw.json        full extraction + block metadata
        crawls/<domain-hash>/block_candidates.json ambiguous blocks for LLM review
        crawls/<domain-hash>/link_graph.json       provisional graph

Phase 2 - apply LLM decisions:
    ./.venv/bin/python3 internal_link_crawler.py --url https://example.com \
        --apply-decisions block_decisions.json

    Reuses crawl_raw.json (no re-fetch), applies the model's block labels, and
    rewrites link_graph.json.

The LLM labels blocks as content | nav | boilerplate. The model only sees
ambiguous blocks; explicit markers and exactly-repeating blocks are handled
deterministically so the common cases stay cheap and reproducible.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin, urlsplit, urlunsplit

import httpx
import networkx as nx
from bs4 import BeautifulSoup

NAV_KEYWORDS = (
    "nav",
    "menu",
    "header",
    "navbar",
    "topbar",
    "breadcrumb",
    "footer",
)

NAV_TAGS = {"nav", "header", "footer"}

BLOCK_TAGS = {
    "ul",
    "ol",
    "div",
    "section",
    "table",
    "tbody",
    "tr",
    "dl",
    "aside",
}

SKIP_SCHEMES = ("mailto:", "tel:", "javascript:", "data:", "sms:", "ftp:")

EXCLUDE_LABELS = {
    "nav",
    "navigation",
    "menu",
    "header",
    "footer",
    "boilerplate",
    "exclude",
    "template",
    "chrome",
}
KEEP_LABELS = {"content", "keep", "body", "main", "include", "article"}


def normalize_url(url: str) -> str:
    """Return a canonical absolute URL without fragment, lowercased host/scheme."""
    parts = urlsplit(url)
    scheme = parts.scheme.lower()
    netloc = parts.netloc.lower()
    if (scheme == "http" and netloc.endswith(":80")) or (
        scheme == "https" and netloc.endswith(":443")
    ):
        netloc = netloc.rsplit(":", 1)[0]
    path = parts.path or "/"
    return urlunsplit((scheme, netloc, path, parts.query, ""))


def canonical_root(start_url: str) -> str:
    """Derive the canonical crawl root (directory scope) from the start URL."""
    parts = urlsplit(start_url)
    path = parts.path or "/"
    if not path.endswith("/"):
        last = path.rsplit("/", 1)[-1]
        if "." in last:
            path = path.rsplit("/", 1)[0] + "/"
        else:
            path = path + "/"
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), path, "", ""))


def in_scope(url: str, root: str) -> bool:
    """True when url is under the canonical root (exact root or descendant)."""
    root_no_slash = root.rstrip("/")
    return url == root_no_slash or url.startswith(root)


def has_nav_marker(tag) -> bool:
    """Detect whether a tag is a structural navigation container."""
    if tag.name in NAV_TAGS:
        return True
    role = (tag.get("role") or "").lower()
    if role in ("navigation", "menu", "menubar"):
        return True
    for attr in ("id", "class", "aria-label"):
        value = tag.get(attr)
        if not value:
            continue
        if isinstance(value, (list, tuple)):
            value = " ".join(value)
        tokens = re.split(r"[^a-zA-Z0-9]+", value)
        for token in tokens:
            low = token.lower()
            if any(keyword in low for keyword in NAV_KEYWORDS):
                return True
    return False


def is_nav_excluded(anchor_tag) -> bool:
    """Walk ancestors to see if the link lives inside a nav-like container."""
    return any(has_nav_marker(parent) for parent in anchor_tag.parents)


def find_link_block(anchor_tag):
    """Return the nearest ancestor that holds 3+ links, else None."""
    for parent in anchor_tag.parents:
        if getattr(parent, "name", None) in BLOCK_TAGS:
            links = parent.find_all("a", href=True)
            if len(links) >= 3:
                return parent
    return None


def block_signature(block, base_url: str) -> tuple[str, ...] | None:
    """Return the sorted absolute href signature of a link block."""
    if block is None:
        return None
    hrefs = []
    for link in block.find_all("a", href=True):
        href = (link.get("href") or "").strip()
        if href and not href.startswith("#"):
            hrefs.append(normalize_url(urljoin(base_url, href)))
    if len(hrefs) < 3:
        return None
    return tuple(sorted(hrefs))


def block_id_for(signature: tuple[str, ...]) -> str:
    digest = hashlib.sha1("\n".join(signature).encode("utf-8")).hexdigest()[:12]
    return f"blk_{digest}"


def anchor_text(anchor_tag) -> str:
    text = anchor_tag.get_text(" ", strip=True)
    if text:
        return text
    img = anchor_tag.find("img")
    if img is not None:
        alt = (img.get("alt") or "").strip()
        if alt:
            return f"[image: {alt}]"
    return "[image]"


def block_position(block) -> str:
    body = block.find_parent("body")
    if body is None:
        return "mid"
    tags = body.find_all(True)
    if not tags:
        return "mid"
    try:
        fraction = tags.index(block) / len(tags)
    except ValueError:
        return "mid"
    if fraction < 0.25:
        return "top"
    if fraction > 0.75:
        return "bottom"
    return "mid"


def block_snippet(block, limit: int = 600) -> str:
    clone = BeautifulSoup(str(block), "lxml")
    for node in clone(["script", "style"]):
        node.decompose()
    collapsed = re.sub(r"\s+", " ", str(clone))
    return collapsed[:limit]


def block_features(block, base_url: str, signature: tuple[str, ...]) -> dict:
    links = block.find_all("a", href=True)
    link_text = " ".join(a.get_text(" ", strip=True) for a in links)
    total_text = block.get_text(" ", strip=True)
    ratio = len(link_text) / max(len(total_text), 1)
    direct = sum(1 for child in block.find_all("a", recursive=False))
    position = block_position(block)
    score = 0.0
    if position in ("top", "bottom"):
        score += 0.4
    if ratio >= 0.6:
        score += 0.3
    if 3 <= len(links) <= 12:
        score += 0.1
    if direct >= 3:
        score += 0.2
    return {
        "tag": block.name,
        "id": block.get("id"),
        "class": " ".join(block.get("class")) if block.get("class") else None,
        "link_count": len(links),
        "link_text_ratio": round(ratio, 3),
        "direct_anchor_count": direct,
        "position": position,
        "nav_marker": has_nav_marker(block),
        "nav_score": round(min(score, 1.0), 3),
        "anchors": [anchor_text(a) for a in links][:15],
        "signature": list(signature),
        "snippet": block_snippet(block),
    }


def domain_dir(netloc: str, base_dir: Path) -> Path:
    slug = re.sub(r"[^a-z0-9]+", "-", netloc.lower()).strip("-") or "site"
    digest = hashlib.sha1(netloc.encode("utf-8")).hexdigest()[:12]
    return base_dir / f"{slug}-{digest}"


def html_filename(url: str) -> str:
    parts = urlsplit(url)
    path = parts.path.strip("/")
    if not path:
        name = "index"
    else:
        name = re.sub(r"[^a-zA-Z0-9]+", "_", path)[:80].strip("_") or "index"
    if parts.query:
        name += "_" + hashlib.sha1(parts.query.encode("utf-8")).hexdigest()[:6]
    return f"{name}-{hashlib.sha1(url.encode('utf-8')).hexdigest()[:8]}.html"


def page_title(soup: BeautifulSoup) -> str:
    if soup.title and soup.title.string:
        return soup.title.string.strip()
    return ""


def compute_pagerank(graph: nx.DiGraph) -> dict[str, float]:
    """PageRank over the internal content graph, without heavy SciPy deps."""
    if graph.number_of_nodes() == 0:
        return {}
    try:
        return nx.pagerank(graph)
    except ImportError:
        from networkx.algorithms.link_analysis.pagerank_alg import _pagerank_python

        return _pagerank_python(graph)


def compute_repeated(raw_links: list[dict]) -> set[tuple[str, ...]]:
    """Signatures that appear on 2+ distinct pages (exact repetition)."""
    signature_pages: dict[tuple[str, ...], set[str]] = defaultdict(set)
    for link in raw_links:
        if link.get("block_signature"):
            signature_pages[tuple(link["block_signature"])].add(link["source"])
    return {sig for sig, sources in signature_pages.items() if len(sources) >= 2}


def normalize_decisions(data) -> dict[str, str]:
    """Accept {'blk_x': 'nav'} or [{'block_id': ..., 'label': ...}] forms."""
    if not data:
        return {}
    if isinstance(data, dict) and "decisions" in data:
        data = data["decisions"]
    out: dict[str, str] = {}
    if isinstance(data, dict):
        items = data.items()
        for key, value in items:
            if isinstance(value, dict):
                value = value.get("label") or value.get("decision")
            if value:
                out[key] = str(value).strip().lower()
    elif isinstance(data, list):
        for item in data:
            if not isinstance(item, dict):
                continue
            key = item.get("block_id") or item.get("id")
            value = item.get("label") or item.get("decision")
            if key and value:
                out[key] = str(value).strip().lower()
    return out


def site_paths(args: argparse.Namespace):
    start_url = normalize_url(args.url)
    root = canonical_root(start_url)
    netloc = urlsplit(start_url).netloc
    site_dir = domain_dir(netloc, Path(args.output_dir).resolve())
    return start_url, root, netloc, site_dir


def build_candidates(
    blocks: dict[str, dict],
    raw_links: list[dict],
    repeated: set[tuple[str, ...]],
    limit: int,
) -> list[dict]:
    page_sets: dict[str, set[str]] = defaultdict(set)
    for link in raw_links:
        if link.get("block_id"):
            page_sets[link["block_id"]].add(link["source"])

    candidates = []
    for block_id, features in blocks.items():
        signature = tuple(features["signature"])
        auto = None
        if signature in repeated:
            auto = "repeated_block"
        elif features.get("nav_marker"):
            auto = "nav_marker"
        if auto == "repeated_block":
            continue
        item = {k: v for k, v in features.items() if k != "signature"}
        item.update(
            {
                "block_id": block_id,
                "page_count": len(page_sets.get(block_id, set())),
                "sample_pages": sorted(page_sets.get(block_id, set()))[:3],
                "auto_excluded": auto,
            }
        )
        candidates.append(item)
    candidates.sort(key=lambda c: c["nav_score"], reverse=True)
    return candidates[:limit]


def finalize(
    raw: dict,
    decisions: dict[str, str],
    site_dir: Path,
    start_url: str,
    root: str,
    netloc: str,
) -> dict:
    pages = raw["pages"]
    raw_links = raw["links"]
    extraction = raw.get("stats", {})
    repeated = compute_repeated(raw_links)

    for page in pages.values():
        page["content_outbound"] = 0
        page["content_inbound"] = 0
        page["nav_inbound"] = 0
        page["pagerank"] = 0.0
        page["is_orphan"] = False
        page.setdefault("is_start", page["url"] == start_url)

    content_links: list[dict] = []
    nav_inbound: Counter = Counter()
    nav_container = 0
    repeating = 0
    llm_excluded = 0
    decided_content = 0

    for link in raw_links:
        signature = (
            tuple(link["block_signature"]) if link.get("block_signature") else None
        )
        label = decisions.get(link.get("block_id"))
        if label in EXCLUDE_LABELS:
            llm_excluded += 1
            continue
        if label in KEEP_LABELS:
            decided_content += 1
            content_links.append(link)
            continue
        if link.get("nav_excluded"):
            nav_container += 1
            nav_inbound[link["target"]] += 1
            continue
        if signature is not None and signature in repeated:
            repeating += 1
            continue
        content_links.append(link)

    content_inbound = Counter(link["target"] for link in content_links)
    for source, count in Counter(link["source"] for link in content_links).items():
        if source in pages:
            pages[source]["content_outbound"] = count

    for target, count in content_inbound.items():
        if target in pages:
            pages[target]["content_inbound"] = count
    for target, count in nav_inbound.items():
        if target in pages:
            pages[target]["nav_inbound"] = count

    graph_net = nx.DiGraph()
    graph_net.add_nodes_from(pages.keys())
    for link in content_links:
        graph_net.add_edge(link["source"], link["target"])
    pagerank = compute_pagerank(graph_net)
    for url, page in pages.items():
        page["pagerank"] = round(pagerank.get(url, 0.0), 6)
        page["is_orphan"] = page["content_inbound"] == 0 and not page["is_start"]

    ranked = sorted(pages.items(), key=lambda item: item[1]["pagerank"], reverse=True)
    pagerank_ranking = [
        {
            "url": url,
            "pagerank": page["pagerank"],
            "content_inbound": page["content_inbound"],
        }
        for url, page in ranked
    ]

    orphans = sorted(url for url, page in pages.items() if page["is_orphan"])
    graph_path = site_dir / "link_graph.json"
    graph = {
        "start_url": start_url,
        "canonical_root": root,
        "domain": netloc,
        "crawled_at": datetime.now(timezone.utc).isoformat(),
        "pages": pages,
        "links": content_links,
        "orphans": orphans,
        "pagerank_ranking": pagerank_ranking,
        "excluded": {
            "nav_container_links": nav_container,
            "repeating_boilerplate_links": repeating,
            "llm_excluded_links": llm_excluded,
            "external_links": extraction.get("external", 0),
            "out_of_scope_links": extraction.get("out_of_scope", 0),
            "non_http_links": extraction.get("non_http", 0),
        },
        "repeating_block_count": len(repeated),
        "llm_decisions_applied": len(decisions),
        "llm_decided_content_links": decided_content,
    }
    graph_path.write_text(json.dumps(graph, indent=2), encoding="utf-8")

    return {
        "ok": True,
        "start_url": start_url,
        "canonical_root": root,
        "domain": netloc,
        "pages_crawled": len(pages),
        "pages_failed": raw.get("failed", []),
        "canonical_boundaries": {
            "root": root,
            "out_of_scope_links_skipped": extraction.get("out_of_scope", 0),
            "external_links_skipped": extraction.get("external", 0),
        },
        "links_extracted": len(content_links),
        "links_excluded": {
            "nav_container": nav_container,
            "repeating_boilerplate": repeating,
            "llm_excluded": llm_excluded,
            "repeating_blocks_detected": len(repeated),
        },
        "llm_decisions_applied": len(decisions),
        "llm_decided_content_links": decided_content,
        "orphan_count": len(orphans),
        "orphans": orphans,
        "link_graph": str(graph_path),
        "html_dir": str(site_dir / "html"),
    }


def crawl(args: argparse.Namespace) -> dict:
    start_url, root, netloc, site_dir = site_paths(args)
    html_dir = site_dir / "html"
    html_dir.mkdir(parents=True, exist_ok=True)

    stats = {
        "out_of_scope": 0,
        "external": 0,
        "non_http": 0,
    }
    failed: list[dict] = []
    pages: dict[str, dict] = {}
    raw_links: list[dict] = []
    blocks: dict[str, dict] = {}
    discovered: set[str] = set()

    headers = {"User-Agent": args.user_agent, "Accept": "text/html,*/*;q=0.8"}
    queue: list[tuple[str, int]] = [(start_url, 0)]
    seen: set[str] = set()

    with httpx.Client(
        follow_redirects=True,
        timeout=args.timeout,
        headers=headers,
        verify=not args.insecure,
    ) as client:
        while queue:
            url, depth = queue.pop(0)
            if url in seen:
                continue
            seen.add(url)
            if len(pages) >= args.max_pages:
                break
            if args.delay > 0:
                time.sleep(args.delay)

            try:
                response = client.get(url)
                response.raise_for_status()
                html = response.content
                final_url = normalize_url(str(response.url))
            except Exception as exc:  # noqa: BLE001 - report and continue
                failed.append({"url": url, "error": str(exc)})
                continue

            file_path = html_dir / html_filename(url)
            file_path.write_bytes(html)

            soup = BeautifulSoup(response.text, "lxml")
            title = page_title(soup)

            page_discovered: set[str] = set()
            for anchor in soup.find_all("a", href=True):
                href = (anchor.get("href") or "").strip()
                if not href or href.startswith("#"):
                    continue
                lowered = href.lower()
                if any(lowered.startswith(scheme) for scheme in SKIP_SCHEMES):
                    stats["non_http"] += 1
                    continue

                absolute = normalize_url(urljoin(final_url, href))
                target_parts = urlsplit(absolute)
                if target_parts.scheme not in ("http", "https"):
                    stats["non_http"] += 1
                    continue
                if target_parts.netloc != netloc:
                    stats["external"] += 1
                    continue
                if not in_scope(absolute, root):
                    stats["out_of_scope"] += 1
                    continue

                page_discovered.add(absolute)

                block = find_link_block(anchor)
                signature = block_signature(block, final_url)
                block_id = block_id_for(signature) if signature else None
                if block_id and block_id not in blocks:
                    blocks[block_id] = block_features(block, final_url, signature)

                parent = anchor.parent
                rel = anchor.get("rel") or []
                if isinstance(rel, str):
                    rel = rel.split()

                raw_links.append(
                    {
                        "source": url,
                        "target": absolute,
                        "anchor": anchor_text(anchor),
                        "parent_tag": getattr(parent, "name", None),
                        "parent_id": parent.get("id") if parent else None,
                        "parent_class": (
                            " ".join(parent.get("class"))
                            if parent and parent.get("class")
                            else None
                        ),
                        "rel": rel,
                        "title": anchor.get("title"),
                        "nav_excluded": is_nav_excluded(anchor),
                        "block_signature": list(signature) if signature else None,
                        "block_id": block_id,
                    }
                )

            discovered |= page_discovered
            pages[url] = {
                "url": url,
                "final_url": final_url,
                "depth": depth,
                "status_code": response.status_code,
                "title": title,
                "html_file": str(file_path),
                "is_start": url == start_url,
            }

            if depth < args.depth:
                for target in sorted(page_discovered):
                    if target not in seen:
                        queue.append((target, depth + 1))

    raw = {
        "start_url": start_url,
        "canonical_root": root,
        "domain": netloc,
        "crawled_at": datetime.now(timezone.utc).isoformat(),
        "stats": stats,
        "failed": failed,
        "pages": pages,
        "links": raw_links,
    }
    raw_path = site_dir / "crawl_raw.json"
    raw_path.write_text(json.dumps(raw, indent=2), encoding="utf-8")

    repeated = compute_repeated(raw_links)
    candidates = build_candidates(blocks, raw_links, repeated, args.candidates_limit)
    candidates_path = site_dir / "block_candidates.json"
    candidates_path.write_text(
        json.dumps(
            {
                "start_url": start_url,
                "canonical_root": root,
                "instructions": (
                    "Label each block content | nav | boilerplate. Write "
                    "block_decisions.json as {\"<block_id>\": \"content|nav|boilerplate\"} "
                    "then re-run with --apply-decisions."
                ),
                "candidates": candidates,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    summary = finalize(raw, {}, site_dir, start_url, root, netloc)
    summary["crawl_raw"] = str(raw_path)
    summary["block_candidates"] = str(candidates_path)
    summary["candidates_pending"] = len(candidates)
    summary["review_required"] = bool(candidates)
    return summary


def apply_decisions(args: argparse.Namespace) -> dict:
    start_url, root, netloc, site_dir = site_paths(args)
    raw_path = site_dir / "crawl_raw.json"
    if not raw_path.exists():
        raise FileNotFoundError(
            f"No crawl found at {raw_path}. Run a crawl with --url first."
        )
    raw = json.loads(raw_path.read_text(encoding="utf-8"))
    decisions = normalize_decisions(
        json.loads(Path(args.apply_decisions).read_text(encoding="utf-8"))
    )
    summary = finalize(raw, decisions, site_dir, start_url, root, netloc)
    summary["crawl_raw"] = str(raw_path)
    summary["block_decisions"] = str(Path(args.apply_decisions).resolve())
    summary["review_required"] = False
    return summary


def parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Crawl and audit internal links under a canonical root.",
    )
    parser.add_argument("--url", required=True, help="Start URL for the crawl.")
    parser.add_argument(
        "--depth", type=int, default=3, help="Maximum crawl depth (default: 3)."
    )
    parser.add_argument(
        "--delay", type=float, default=0.0, help="Delay between requests in seconds."
    )
    parser.add_argument(
        "--max-pages", type=int, default=200, help="Hard cap on pages crawled."
    )
    parser.add_argument(
        "--timeout", type=float, default=15.0, help="Per-request timeout in seconds."
    )
    parser.add_argument(
        "--output-dir", default="crawls", help="Base output directory (default: crawls)."
    )
    parser.add_argument(
        "--user-agent",
        default="InternalLinkAuditor/1.0 (+https://example.com/bot)",
        help="HTTP User-Agent header.",
    )
    parser.add_argument(
        "--insecure",
        action="store_true",
        help="Disable TLS certificate verification.",
    )
    parser.add_argument(
        "--apply-decisions",
        metavar="PATH",
        help="Apply an LLM block-decision JSON to an existing crawl (no re-fetch).",
    )
    parser.add_argument(
        "--candidates-limit",
        type=int,
        default=150,
        help="Max ambiguous blocks emitted for LLM review (default: 150).",
    )
    return parser.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)
    try:
        summary = apply_decisions(args) if args.apply_decisions else crawl(args)
    except Exception as exc:  # noqa: BLE001 - emit JSON error contract
        json.dump({"ok": False, "error": str(exc)}, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 1
    json.dump(summary, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
