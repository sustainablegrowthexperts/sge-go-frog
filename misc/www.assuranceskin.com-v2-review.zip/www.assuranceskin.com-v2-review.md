# www.assuranceskin.com — v2 Deterministic Audit Review

**Prepared:** 2026-10-29
**Scope:** Review of the v2 deterministic audit against the live site and the prior deterministic/agentic comparison.
**Changes made:** None to the tool, crawl artifacts, or v2 output. This document is read-only analysis.

---

## 1. Inputs and artifacts

| Artifact | Path | Used for |
|---|---|---|
| v2 audit ZIP | `misc/www.assuranceskin.com v2 audit.zip` | Reviewed output |
| v2 `audit.json` | extracted from the ZIP | Summary, filters, blocks, PageRank, exclusions |
| v2 `audit-pages.csv` | extracted from the ZIP | Page-level inbound/outbound, reachability, orphan flags |
| v2 `audit-blocks.csv` | extracted from the ZIP | Block decisions, reasons, classes, signatures |
| v2 `audit-links.csv` | extracted from the ZIP | Full link inventory, decisions, reasons, target types |
| v1 deterministic audit | `misc/audit-comparison-bundle/deterministic/www.assuranceskin.com/audit.json` | Baseline metrics and link set |
| Prior comparison report | `misc/deterministic-audit-comparison.md` | Earlier findings and recommendations |
| Agentic baseline (reference) | `misc/audit-comparison-bundle/agentic/www.assuranceskin.com/link_graph.json` | Content-link/orphan/PageRank reference |

Timestamps:

- v1 deterministic: `generated_at = 2026-10-29T01:56:33Z`
- v2 deterministic: `crawled_at = 2026-10-29T07:26:50Z`, `generated_at = 2026-10-29T07:26:53Z`

Because both runs are from the same day, the large differences below are tool behavior, not crawl drift.

---

## 2. Live-site sources

Live pages were fetched on 2026-10-29 and parsed for anchor targets and ancestor classes.

| Source URL | Used to verify |
|---|---|
| `https://www.assuranceskin.com/` | Homepage service links inside `div.content-block`; main-menu links |
| `https://www.assuranceskin.com/aesthetic-dermatology/acne-scar-removal-and-treatment/` | Related-post links inside `div.columns recent-posts-body` |
| `https://www.assuranceskin.com/blog/` | Blog post links inside `ul.blog-slider` |
| `https://www.assuranceskin.com/products/` | Product listing links inside the product section |
| `https://www.assuranceskin.com/cn/medical-dermatology/allergy/` | Content link to a 301 redirect alias |
| `https://www.assuranceskin.com/cn/medical-dermatology/eczema/` | Confirmed HTTP 301 to `/medical-dermatology/eczema-treatment-singapore/` |
| `https://www.assuranceskin.com/?page_id=5430` | Confirmed HTTP 404 |

Reproduction pattern used for the HTML checks:

```bash
curl -sL "https://www.assuranceskin.com/products/" -o products.html
# then parse <a> elements and their ancestor class chains
curl -sI "https://www.assuranceskin.com/cn/medical-dermatology/eczema/"
curl -sI "https://www.assuranceskin.com/?page_id=5430"
```

---

## 3. Verdict

The v2 output is **stronger as a reporting artifact** but has **two kinds of problems**:

1. **Intentional strictness** — pages whose only inbound links come from related-post widgets, blog carousels, or product/listing grids are now flagged. This is a legitimate policy direction.
2. **Provable bugs** — the strictness is implemented with broad class-substring exclusions that also remove primary-site links and corrupt reachability metrics. Some reported values are factually false against the live site.

The strictness goal is reasonable. The implementation currently makes the strict signals misleading.

---

## 4. Metrics comparison (Askin)

| Metric | v1 | v2 | Change |
|---|---:|---:|---:|
| Pages | 159 | 177 | +18 (sitemap-only pages included) |
| Content link occurrences | 1,078 | 515 | **-52%** |
| Unique content source → target pairs | 836 | 487 | **-42%** |
| Orphans (content inbound = 0) | 8 | 57 | **+49** |
| Content unreachable from start | — | 176 of 177 | new metric |
| Nav links | 22,239 | 3,928 | -18,311 |
| Excluded links | not exported | 22,038 | new full export |
| Boilerplate links | 97 | 0 | |
| External links | 922 | 1,081 | |
| Non-HTTP links | 1,377 | 1,553 | |
| Top PageRank share | 5.28% | 8.90% | +3.62 pts |
| Blocks | 500 | 538 | |
| Block decisions | — | content 199, nav 172, excluded 167 | |

Per-page content outbound:

| Page | v1 | v2 |
|---|---:|---:|
| `/` | 56 | **0** |
| `/cn` | 54 | **0** |
| `/blog` | 79 | **2** |
| `/products` | 18 | **0** |

Source: v2 `audit.json` (`summary`, `structure`, `pagerank_meta`, `excluded`) and v1 `audit.json` (`summary`, `links`, `pages`).

---

## 5. What is defensible as strictness

Pages that previously looked healthy only because of recirculation/listing links are now surfaced. That includes:

- Blog posts linked only from `ul.blog-slider` listing carousels.
- Products linked only from the product listing grid.
- Pages linked only from `div.columns recent-posts-body` related-post blocks.

If the intent is "force an SEO specialist to confirm real contextual links," this behavior is working as designed. These pages appear in the v2 orphan list (57 total), and 33 of the 49 new orphans had content inbound in v1.

Source: v2 `audit.json` `orphans`; v1 `links` cross-reference.

---

## 6. Provably wrong findings

### 6.1 Homepage content outbound is reported as 0

**v2 says:** homepage `Content Outbound = 0`, `Content Outbound Unique = 0`.

**Live page shows:** `https://www.assuranceskin.com/` contains a primary service directory inside `div.content-block` with **55 unique internal hrefs**, including:

- `/medical-dermatology/acne-treatment-singapore/`
- `/medical-dermatology/hives/`
- `/medical-dermatology/rosacea/`
- `/medical-dermatology/eczema-treatment-singapore/`
- `/aesthetic-dermatology/melasma/`
- `/aesthetic-dermatology/hifu-skin-tightening/`
- `/surgical-dermatology/mole-removal-singapore/`

These are not hidden or script-only links; they are the main service listing with descriptive anchors.

**Why v2 drops them:** the blocks are `content` at block level, but their links are excluded at link level with `excluded_class:grid-wrap`, `excluded_class:grid2`, or `excluded_class:grid25`. The generic `grid` token in `filters_used.exclude_substrings` matches layout wrappers.

Sources:

- v2 `audit-pages.csv`, homepage row
- v2 `audit-links.csv`, homepage rows with `Decision=excluded`
- v2 `audit.json`, `filters_used.exclude_substrings`
- Live `https://www.assuranceskin.com/`

### 6.2 Reachability from start is degenerate

**v2 says:** `Content Reachable From Start = false` for **176 of 177** pages.

That follows directly from the homepage having zero content edges. It is not a site finding; it is an artifact. The homepage plainly links to the service pages above, so reporting them as unreachable from the start URL is incorrect as a reachability statement.

Source: v2 `audit-pages.csv`, column `Content Reachable From Start`.

### 6.3 Nav-reachable is wrong for menu pages

**Example:** `/medical-dermatology/hives/` is in the live main navigation (it appears in the homepage menu). v2 reports `Nav Inbound = 1` but `Nav Reachable = false`.

**Cause:** the homepage submenu block containing Hives (`blk_a90eeb067030`, `ul.sub-menu submenu metismenu`) is labeled `excluded` with reason `excluded_class:col-grid`, while a sibling submenu (`blk_691345938665`) is correctly `nav` with reason `nav_marker`. The same menu system is split by a class substring.

Additional examples: `/medical-dermatology/acne-treatment-singapore` also has `Nav Reachable = false`.

Sources:

- v2 `audit-pages.csv`
- v2 `audit-blocks.csv`
- v2 `audit-links.csv`, homepage → Hives rows
- Live `https://www.assuranceskin.com/`

### 6.4 Redirect links are dropped instead of credited

**Live page:** `https://www.assuranceskin.com/cn/medical-dermatology/allergy/` contains:

```html
<a href="https://www.assuranceskin.com/cn/medical-dermatology/eczema/">皮炎</a>
```

`https://www.assuranceskin.com/cn/medical-dermatology/eczema/` returns **HTTP 301** to `https://www.assuranceskin.com/medical-dermatology/eczema-treatment-singapore/`.

**v2 behavior:** the link is classified `redirect_target` and dropped. The final page never receives the inbound credit.

This is not strictness; it undercounts a real internal link whose equity flows through the 301. The prior report recommended resolving aliases to the final page before counting, not deleting them.

v2 also has 8 `redirect_target` links and 6 `target_not_page` links, all excluded from the content graph.

Sources:

- v2 `audit.json`, `redirects`, `excluded.redirect_target_links`, `excluded.non_page_target_links`
- v2 `audit-links.csv`, rows with `Reason=redirect_target`, `Reason=target_not_page`
- Live URLs listed above

### 6.5 Broken internal links are not flagged as broken

**v2 says:** 6 links to `https://www.assuranceskin.com/?page_id=5430` are `Target Type = non_page`, `Reason = target_not_page`.

**Live check:** that URL returns **HTTP 404**.

There is no target-status or broken-link column in the export. A 404 internal link should be reported as broken regardless of the strictness policy.

Sources:

- v2 `audit-links.csv`, `Reason=target_not_page` rows
- Live `https://www.assuranceskin.com/?page_id=5430`

### 6.6 `audit-links.csv` is not valid UTF-8

Decoding the file as UTF-8 fails at byte offset ~3,083,705. The likely cause is byte-based truncation of a multi-byte anchor/context field. `audit.json`, `audit-pages.csv`, and `audit-blocks.csv` are valid UTF-8.

Source: v2 `audit-links.csv`.

### 6.7 Content-container detection is still failing

- `page_has_content_container = true` for only **14 of 538** blocks.
- `inside_content = false` for **all 538** blocks.

Consequently, some decisions come from failed main detection rather than policy. Example: on `/cn`, `blk_4c29d398937c` (`div.container`, containing real blog links) is `nav` with reason `high_nav_score_no_main`. The same block in a strict policy might be excluded as a listing, but the recorded reason is a detector failure.

Sources: v2 `audit.json` `blocks`; v2 `audit-blocks.csv`.

---

## 7. Root cause: broad class-substring exclusion

`filters_used.exclude_substrings` includes generic layout tokens:

```text
related, recommend, recirc, similar, suggest, trending, popular, latest,
recent, curated, spotlight, picks, stream, grid, teaser, crosslink,
cross-promo, read-next, slider, slide, carousel, swiper, slick, splide,
glide, flick, marquee, ticker, rotator, strip, lightbox, filmstrip, scroller
```

Any block whose class matches is hard-excluded with `excluded_class:<token>`. This produces:

| Reason | Links excluded | What it caught |
|---|---:|---|
| `excluded_class:col-grid` | 20,802 | Menu/submenu links |
| `excluded_class:recent-posts-body` | 606 | Related-post content blocks |
| `excluded_class:grid25` | 349 | Layout wrappers, blog cards, product cards |
| `excluded_class:grid-wrap` | 160 | Content wrappers, homepage service directory |
| `excluded_class:grid2` | 105 | Homepage/service layout wrappers |
| `excluded_class:slideshow-contain` | 2 | Slideshow container |

Block-level counts:

| Block class | Blocks excluded |
|---|---:|
| `div.columns recent-posts-body` | 92 |
| `ul.blog-slider ...` | 47 |
| `ul` with `grid2` ancestor | 12 |
| `div.product-img ... grid25` | 6 |
| `div.about-cms grid-wrap` / others | 4 |
| `ul.sub-menu submenu metismenu` (`col-grid`) | 6 |

The rule is not semantic. On this site it removes:

- the homepage's primary service directory,
- the `/products` product listing (6 product pages),
- the `/blog` post listing (23 post links in `ul.blog-slider`),
- the related-post blocks from the prior report.

The first two examples are why homepage/reachability metrics break. The strict policy may want to drop the last two, but the tool is not distinguishing them.

Sources:

- v2 `audit.json`, `filters_used`, `excluded`, `structure`
- v2 `audit-blocks.csv`, `Decision=excluded` rows
- v2 `audit-links.csv`, `Reason=excluded_class:*` rows

---

## 8. Prior report items: status

| Prior recommendation | v2 status |
|---|---|
| P0.1 Fix content-container detection; prevent nav overrides | **Not fixed** (14/538 true, `inside_content` all false). Replaced by class exclusion. |
| P0.2 Resolve redirects before counting | **Not fixed** — redirects are excluded, not resolved/credited. |
| P1.3 Separate assets from pages | Partially indicated in `pagerank_meta` (`asset_targets_excluded: true`); no SGE v2 artifact supplied to verify. |
| P1.4 Export all links and block evidence | **Done well** — full 29,320-row link inventory; block signatures, snippets, sample links. |
| P1.5 Reachability-based orphan reporting | **Added**, but corrupted by zeroed homepage edges (176/177 unreachable). |
| P2.6 Occurrences vs unique links | **Done** — unique columns added. |
| P2.7 Handle repeated content blocks conservatively | **Not done conservatively** — blanket class exclusion instead. |
| P2.8 Document PageRank methodology | **Done** — `pagerank_meta` documents node/edge/dangling rules. |
| P2.9 Fix/remove dead block fields | **Done** — dead fields removed. |
| P2.10 Flag broken internal links | **Partial** — `target_not_page` exists, but no HTTP status/broken flag; 404 not surfaced. |
| P2.11 Reconcile external/non-HTTP counts | **Done** — full link inventory supports reconciliation. |

Source: `misc/deterministic-audit-comparison.md` Sections 4–11; v2 artifacts.

---

## 9. Recommendations that preserve the strictness goal

These are suggestions only; nothing was changed.

1. Separate the policies instead of one `excluded` bucket:
   - `content` (contextual body links)
   - `nav`
   - `listing` (category/blog/product indexes)
   - `related` (related-post/recirculation widgets)
   - `boilerplate`
   - `broken`
2. Do not use layout tokens (`grid`, `col`) to classify links. Use structural/semantic evidence (card/list patterns, repeated signatures) or explicit selectors, and report the policy name in `Reason`.
3. Never let the start URL have zero content edges. If the homepage's service directory is intentionally `listing`/`nav`, still compute reachability through the union of content + listing + nav, and label the path type.
4. Resolve 301 targets to the final page before inbound/PageRank/orphan counting, or count them both at the alias and final page.
5. Add `target_status` and `broken` columns so 404s are explicit.
6. Keep `excluded_class` for genuinely presentational containers only, and require a class token to match on a word boundary (e.g. `recent-posts-body`), not a substring (`grid` inside `grid25` and `col-grid`).
7. Fix the CSV writer to write full UTF-8 (no byte-length truncation).
8. Re-run content-container detection and record it separately from the strict policy, so "nav because no `<main>`" is never mistaken for a chosen exclusion.

---

## 10. Bottom line

- The **observability** changes are real improvements: full link inventory, block evidence, PageRank methodology, unique counts, dead-field cleanup.
- The **strictness direction** is valid: flagging pages that rely only on listing/related links is useful.
- But the **implementation** produces factually false results on the live site: homepage outbound 0, 176/177 pages unreachable from start, menu pages not nav-reachable, 301 links not credited, and a 404 not flagged. These are bugs independent of the strictness policy.

The key fix is to make exclusions semantic and multi-category, and to stop using generic layout-class substrings (`grid`) as a proxy for "listing/recirculation."

---

## 11. Source index

**Local artifacts**

- `misc/www.assuranceskin.com v2 audit.zip`
- `misc/www.assuranceskin.com-v2-review.md` (this file)
- `misc/deterministic-audit-comparison.md`
- `misc/audit-comparison-bundle/deterministic/www.assuranceskin.com/audit.json`
- `misc/audit-comparison-bundle/agentic/www.assuranceskin.com/link_graph.json`

**Live-site checks**

- `https://www.assuranceskin.com/`
- `https://www.assuranceskin.com/aesthetic-dermatology/acne-scar-removal-and-treatment/`
- `https://www.assuranceskin.com/blog/`
- `https://www.assuranceskin.com/products/`
- `https://www.assuranceskin.com/cn/medical-dermatology/allergy/`
- `https://www.assuranceskin.com/cn/medical-dermatology/eczema/` → 301
- `https://www.assuranceskin.com/?page_id=5430` → 404

**v2 fields referenced**

- `audit.json`: `summary`, `structure`, `excluded`, `filters_used`, `pagerank_meta`, `orphans`, `redirects`, `blocks`
- `audit-pages.csv`: `Content Outbound`, `Content Inbound`, `Content Reachable From Start`, `Nav Reachable`, `Is Orphan`, `Sitemap Only`
- `audit-blocks.csv`: `Decision`, `Reason`, `Class`, `Link Count`, `Signature`
- `audit-links.csv`: `Source`, `Target`, `Anchor`, `Parent Class`, `Block ID`, `Decision`, `Reason`, `Target Type`
